function getAjaxObject() {
	try {
		// create XMLHttpRequest for firefox, safari, opera
		ajaxObject = new XMLHttpRequest();
	} catch (e) {
		try {
			// create XMLHttpRequest for IE 6.0+
			ajaxObject = new ActiveXObject('Msxml2.XMLHTTP');
		} catch (e) {
			try {
				// create XMLHttpRequest for IE 6.0+
				ajaxObject = new ActiveXObject('Microsoft.XMLHTTP');
			} catch (e) {
				alert('Your browser is not supporting AJAX');
			}
		}
	}
	return ajaxObject;
}


function validate() {
	if (select('username').value && select('password').value) {
		console.log('fields are validated');
		performLogin();
	} else {
		select("responseDiv").setAttribute('class', 'alert alert-danger alert-dismissable');
		select("responseDiv").innerHTML = "";
		document.querySelectorAll("div.loginDiv")[0].style.margin = "1% auto 0";
		select("responseDiv").style.display = "block";
		select("responseDiv").innerText = "Please enter both username and password";
	}

}

function redirect() {

	window.location = "index.php";
}


function select(id) {
	return document.getElementById(id);
}

function redirectHelper(ajaxRequest) {
	if (ajaxRequest.status == 302)
		redirect();
}

function performLogin() {

	var username = select('username').value;
	var password = select('password').value;


	ajaxRequest = getAjaxObject();
	ajaxRequest.onreadystatechange = function() {
		if (ajaxRequest.readyState == 4) {
			// if (ajaxRequest.responseText.indexOf("{'redirect':'true'}") >= 0) {
			// 	window.location.href = 'http://localhost/EMS-UI/login.php?expire=true';
			// 	return;
			// }
			//redirectHelper(ajaxRequest);
			console.log(ajaxRequest.responseText);
			if (ajaxRequest.responseText === 'ORA-28000: the account is locked') {

				$('#responseDiv').removeClass();
				$('#responseDiv')
					.addClass('alert')
					.addClass('alert-danger')
					.addClass('alert-dismissable')
					.children('p').text('Your account has been locked due to security measures. Please contact the administrator');
				document.querySelectorAll("div.loginDiv")[0].style.margin = "1% auto 0";
				select("responseDiv").style.display = "block";
			} else if (ajaxRequest.responseText === 'ORA-01017: invalid username/password; logon denied') {
				$('#responseDiv').children('img').attr('src', '');
				select("responseDiv").setAttribute('class', 'alert alert-danger');

				document.querySelectorAll("div.loginDiv")[0].style.margin = "1% auto 0";
				select("responseDiv").style.display = "block";
				$('#responseDiv').children('p').text('Incorrect username and password combination provided. Please try again');

			} else if (ajaxRequest.responseText === 'success') {
				$('#responseDiv').children('img').attr('src', '');
				select("responseDiv").style.display = "block";
				select("responseDiv").setAttribute('class', 'alert alert-success');
				var img = document.createElement('img');
				img.setAttribute('src', 'spinner.gif');

				//select("responseDiv").appendChild(img);
				//select("responseDiv").insertAdjacentElement("beforeend",p);
				$('#responseDiv')
					.children('p').text("You have successfully logged in. Please wait while you are being redirected");
				select("responseDiv").appendChild(img);
				setTimeout(function() {
					redirect();
				}, 1000);
			} else if (ajaxRequest.responseText === 'ORA-12541: TNS:no listener') {
				$('#responseDiv').children('img').attr('src', '');
				select("responseDiv").setAttribute('class', 'alert alert-danger');

				document.querySelectorAll("div.loginDiv")[0].style.margin = "1% auto 0";
				select("responseDiv").style.display = "block";
				$('#responseDiv').children('p').text('Database Listener incorrectly configured. Please contact administrator');
			}
		} else {
			select("responseDiv").setAttribute('class', 'alert alert-info');
			select("responseDiv").innerHTML = "";
			document.querySelectorAll("div.loginDiv")[0].style.margin = "1% auto 0";
			select("responseDiv").style.display = "block";
			var img = document.createElement('img');
			img.setAttribute('src', 'spinner.gif');
			var p = document.createElement('p');
			p.innerText = "Please wait while your are authenticated";

			//select("responseDiv").insertAdjacentElement("beforeend",p);
			$('#responseDiv').append("<p>Please wait while your are authenticated</p>");
			select("responseDiv").appendChild(img);
		}
	}

	var data = "username=" + username + "&password=" + password;
	username = encodeURIComponent(username);
	password = encodeURIComponent(password);

	ajaxRequest.open("POST", "connect.php", true);
	ajaxRequest.timeout = 10000;
	ajaxRequest.ontimeout = function() {
		$('#responseDiv').children('img').attr('src', '');
		select("responseDiv").setAttribute('class', 'alert alert-danger');

		document.querySelectorAll("div.loginDiv")[0].style.margin = "1% auto 0";
		select("responseDiv").style.display = "block";
		$('#responseDiv').children('p').text('Connection has timed out. Please try later');
	}
	ajaxRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	ajaxRequest.send(data);
}

select("login").onclick = validate;

$('#username').keypress(function(event) {
	/* Act on the event */
	//event.preventDefault();
	if(event.which == 13)
		$('#login').click();
});

$('#password').keypress(function(event) {
	/* Act on the event */
	//event.preventDefault();
	if(event.which == 13)
		$('#login').click();
});


jQuery(document).ready(function($) {
	var href = window.location.href;
	if (href.indexOf('?expire=true') > 0) {
		console.log('url contains expire token... setting expired message');
		$('#responseDiv').children('img').attr('src', '');
		select("responseDiv").setAttribute('class', 'alert alert-danger');

		document.querySelectorAll("div.loginDiv")[0].style.margin = "1% auto 0";
		select("responseDiv").style.display = "block";
		$('#responseDiv').children('p').text('Your session has expired. Please login again.');
	}else{
		console.log('no expire token in url');
		$('#responseDiv').children('img').attr('src', '');
		select("responseDiv").setAttribute('class', 'alert alert-info');

		document.querySelectorAll("div.loginDiv")[0].style.margin = "1% auto 0";
		select("responseDiv").style.display = "block";
		$('#responseDiv').children('p').text('Too many login attempts may get your account locked. Exercise extreme caution.');
	}
});