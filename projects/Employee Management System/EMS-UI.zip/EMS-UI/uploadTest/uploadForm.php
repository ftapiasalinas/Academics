<?php
include('base.php');
//&& isset($_SESSION('username') && isset($_SESSION['password'])
checkActivity($_GET);
$_SESSION['LAST_ACTIVITY'] = time(); 
if(isset($_SESSION['loggedIn']) ){
  checkPrivileges('update');
?>

<div class="panel panel-default">
    <div class="panel-heading">
      <div><h3 class="panel-title">Update File</h3></div>
      <button id='updateBackButton' class='btn btn-default btn-xs'>Back</button>
    </div>
    <div class="panel-body">
      <span class="btn btn-default btn-file">
      Browse <input type="file">
      </span>

      <p>Upload progress</p>
      <div class="progress progress-striped active" id='progress'>
        <div class="progress-bar"  role="progressbar" aria-valuemin="0" aria-valuemax="100">
          <span class="sr-only">0% Complete</span> <!-- screen readers only -->
        </div>
      </div>
    <button class='btn btn-primary' id='processFile'>Update</button>
    </div>
</div>  
<?php
}else{
  redirectToLoginPage();
}
?>
  