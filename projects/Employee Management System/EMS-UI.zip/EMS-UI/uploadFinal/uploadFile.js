function fileUploadHandlers() {

    function printUpdateResult(data) {
        var text = '';
        for (item in data) {
            if (!data[item]) {
                text += '<p>Employee with ID number ' + item + ' could not be updated.</p>';
            }
        }
        if (text === '')
            text = '<p>All Employee IDs have been updated successfully.</p>';
        else
            text += '<p>All other Employee IDs have been updated. For unsuccessful updates, please check csv file for errors and retry</p>';
        $('#uploadAlertDiv')
            .hide()
            .fadeIn('fast', function() {}).removeClass('alert-danger').addClass('alert-info').children('p').html(text);
    }

    $('#updateBackButton').click(function(event) {
        /* Act on the event */
        $('#uploadFileDiv').fadeOut('fast', function() {
            $('#choicesPanel').fadeIn('fast', function() {

            });
        });
    });

    $('#updateResetButton').click(function(event) {
        /* Act on the event */
        $('#uploadAlertDiv').fadeOut('fast', function() {

        }).removeClass('alert-danger').addClass('alert-info').children('p').text('');
        $('#uploadContainer button#updateRecords')
            .fadeOut('fast', function() {});
        $('#uploadContainer button#submit')
            .fadeIn('fast', function() {});

        $('#myForm').each(function(index, el) {
            this.reset();
        });

        $(".progress-bar").hide()
            .width(0 + '%').show();
    });

    $(document)
        .on('change', '.btn-file :file', function() {
            var $this = $(this),
                label = $this.val().replace(/\\/g, '/').replace(/.*\//, '');

            $this.trigger('fileselect', label);
            $('uploadContainer #submit').prop('disabled', false);
        });


    $('.btn-file :file').on('fileselect', function(event, label) {
        var input = $(this).parents('.input-group').find(':text'),
            log = label;


        if (input.length) {
            input.val(log);
        } else {
            if (log) alert(log);
        }

    });



    var options = {
        beforeSend: function() {
            //$("#progress").show();
            //clear everything
            $(".progress-bar").width('0%');
            //$("#message").html("");
            //$("#percent").html("0%");
        },
        uploadProgress: function(event, position, total, percentComplete) {
            $(".progress-bar").width(percentComplete + '%');
            //$("#percent").html(percentComplete+'%');
        },
        success: function() {
            $(".progress-bar")
                .width('100%')
                .parent().removeClass('active');
        },
        complete: function(response) {
            redirectHelper(response);
            if (response.responseText !== 'Success') {

                // $('#progress').fadeOut('fast', function() {

                // });

                $('#uploadAlertDiv').fadeIn('fast', function() {

                }).removeClass('alert-info').addClass('alert-danger').children('p').text(response.responseText);
            } else {
                // $('#progress').fadeOut('fast', function() {

                // });

                $('#uploadAlertDiv').fadeIn('fast', function() {

                }).removeClass('alert-danger').addClass('alert-info').children('p').text('Successfully Processed File. Please proceed with update');
                $('#uploadContainer button#submit').fadeOut('fast', function() {
                    $('#uploadContainer button#updateRecords')
                        .fadeIn('fast', function() {})
                        .click(function(event) {
                            /* Act on the event */
                            event.preventDefault();
                            var ajaxRequest = getAjaxObject();
                            ajaxRequest.onreadystatechange = function() {
                                if (ajaxRequest.readyState == 4) {
                                    if (ajaxRequest.responseText.charAt(0) === '<') {
                                        $('#uploadAlertDiv').fadeIn('fast', function() {

                                        }).addClass('alert-danger').children('p').text('Unexpected response received from server. Please contact administrator');

                                        return;
                                    }

                                    if (ajaxRequest.responseText.indexOf("{'redirect':'true'}") >= 0) {
                                        window.location.href = 'http://localhost/EMS-UI/login.php?expire=true';
                                        return;
                                    }
                                    //    //redirectHelper(ajaxRequest);
                                    var result = JSON.parse(ajaxRequest.responseText);
                                    printUpdateResult(result);
                                    console.log(result);
                                }else{
                                   console.log('waiting for response');
                                   $('#uploadAlertDiv').addClass('alert-info').children('p').text('Working...');
                                       // .append('<img src=\'spinner.gif\'>');
                                }
                            }
                            ajaxRequest.open('GET', 'uploadFinal/update.php?ajax=true', true);
                            ajaxRequest.send(null);
                        });
                });
            }

        },
        error: function() {
            $("#message").html("<font color='red'> ERROR: unable to upload files</font>");

        },
        url: 'uploadFinal/upload.php', // override for form's 'action' attribute 
        type: 'POST', // 'get' or 'post', override for form's 'method' attribute 
        dataType: 'html' // 'xml', 'script', or 'json' (expected server response type) 
    };

    // bind to the form's submit event 
    $('#submit').click(function(event) {
        event.preventDefault();
        $this = $('input[name=\'myfile\']');
        var fileSize = false,
            fileType = false;
        if ($this[0].files.length == 0) {
            $('#uploadAlertDiv').fadeIn('fast', function() {

            }).removeClass('alert-danger').addClass('alert-info').children('p').text('Please select a file');
            $('uploadContainer #submit').prop('disabled', true);
            return;
        } else {
            $('uploadContainer #submit').prop('disabled', false);
        }
        if (($this[0].files[0].size) > 102400) { // file size check
            $('#uploadAlertDiv').fadeIn('fast', function() {

            }).removeClass('alert-danger').addClass('alert-info').children('p').text('File Size should not exceed 100KB');
            $('uploadContainer #submit').prop('disabled', true);
            return;
        } else {
            $('#uploadAlertDiv').fadeOut('fast', function() {
                fileSize = true;
            }).children('p').text('');
            $('uploadContainer #submit').prop('disabled', false);
        }
        // file type check

        var array = $this[0].files[0].name.split('.');
        var type = array[array.length - 1];
        if (type !== 'csv') {

            $('#uploadAlertDiv').hide().fadeIn('fast', function() {

            }).removeClass('alert-danger').addClass('alert-info').children('p').text('Please select a csv file');

            $('uploadContainer #submit').prop('disabled', true);
            return;
        } else {
            $('#uploadAlertDiv').fadeOut('fast', function() {
                fileType = true;
            }).removeClass('alert-danger').addClass('alert-info').children('p').text('');
            $('uploadContainer #submit').prop('disabled', false);
        }



        /* Act on the event */

        if (fileSize && fileType) {
            // $('#progressDiv').fadeIn('1', function() {

            // });
            $('#myForm').ajaxSubmit(options);
        }


    });
}