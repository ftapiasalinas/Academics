<?php

include('base.php');
if (($handle = fopen('files/updateData.csv', "r")) !== FALSE) {
			if(fgetcsv($handle)==NULL){
				echo 'Invalid csv file uploaded. Please download the sample file and make changes to it.';	
			}else{
				$handle = fopen('files/updateData.csv','r');
				if(($data = fgetcsv($handle, ",")) !== FALSE){
					//var_dump($data);
					$num = count($data);
					if($num!=7 || $data[0] !=='ID' || $data[1] !=='NAME' || $data[2] !=='PAYSCALE' || $data[3] !=='JOINDATE' ||$data[4] !=='ENDDATE' ||$data[5] !=='SKILLS' ||$data[6] !=='SALARY'){
						echo 'File does not conform to requirements. Please upload the correct file.';
						return;
					}else{
						$_SESSION['filename'] = 'files/updateData.csv';
						echo 'Success';
					}
				}
			}
    		fclose($handle);
}else{
	echo 'Cannot open file. Please contact administrator.';
}
?>