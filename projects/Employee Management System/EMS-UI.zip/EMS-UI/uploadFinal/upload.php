<?php
include('../base.php');
$output_dir = "files/";
//var_dump($_FILES);

checkPrivileges('update');

if(isset($_FILES["myfile"]))
{
	
	//Filter the file types , if you want.
	//var_dump($_FILES['myfile']);	
	if ($_FILES["myfile"]["error"] > 0)
	{
	  echo "Error: " . $_FILES["file"]["error"] . "<br>";
	}
	else
		if (($handle = fopen($_FILES['myfile']['tmp_name'], "r")) !== FALSE) {
			if(fgetcsv($handle)==NULL){
				echo 'Invalid csv file uploaded. Please download the sample file and make changes to it.';	
			}else{

				$handle = fopen($_FILES['myfile']['tmp_name'], "r");

				if(($data = fgetcsv($handle, ",")) !== FALSE){
					$num = count($data);
					if($num!=7 || $data[0] !=='ID' || $data[1] !=='NAME' || $data[2] !=='PAYSCALE' || $data[3] !=='JOINDATE' ||$data[4] !=='ENDDATE' ||$data[5] !=='SKILLS' ||$data[6] !=='SALARY'){
						echo 'File does not conform to requirements. Please upload the correct file.';
						return;
					}else{
						move_uploaded_file($_FILES["myfile"]["tmp_name"],$output_dir.$_FILES["myfile"]["name"]);
    					$_SESSION['filename'] = $_FILES['myfile']['name'];
						echo 'Success';
						return;
					}
				}
				echo 'Unexpected Error';
			}
    		fclose($handle);
		}else{
			echo 'Cannot open file. Please contact administrator.';
		}

	// {
	// 
	// }
}
?>