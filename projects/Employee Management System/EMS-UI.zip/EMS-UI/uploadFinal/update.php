<?php
include('../base.php');
$csvFile = 'files/'.$_SESSION['filename'];

checkPrivileges('update');

if(isset($csvFile))
{
	if (($handle = fopen($csvFile, "r")) !== FALSE) {
		if(fgetcsv($handle)==NULL){
			echo 'Invalid csv file uploaded. Please download the sample file and make changes to it.';	
		}else{

			$handle = fopen($csvFile, "r");
			
			if(($data = fgetcsv($handle, ",")) !== FALSE){
				$num = count($data);
				if($num!=7 || $data[0] !=='ID' || $data[1] !=='NAME' || $data[2] !=='PAYSCALE' || $data[3] !=='JOINDATE' ||$data[4] !=='ENDDATE' ||$data[5] !=='SKILLS' ||$data[6] !=='SALARY'){
					echo 'File does not conform to requirements. Please upload the correct file.';
					return;
				}else{
					$handle = fopen($csvFile, "r");
					$row = 0;
					$keys = fgetcsv($handle,',');
					//var_dump($keys);
					$handle = fopen($csvFile, "r");
					while(($data = fgetcsv($handle,',')) !== FALSE){
						$row++;
						if($row == 1)
							continue;
						$resources[] = array_combine($keys, $data);
					}
					prepareSQL($resources);
					//var_dump($resources);		
					return;
				}
			}
			echo 'Unexpected Error';
		}
		fclose($handle);
	}else{
		echo 'Cannot open file. Please contact administrator.';
	}

	// {
	// //move the uploaded file to uploads folder;
 //    //move_uploaded_file($_FILES["myfile"]["tmp_name"],$output_dir.$_FILES["myfile"]["name"]);
 //    echo "Uploaded File :".$_FILES["myfile"]["name"];
	// }
}else{
	echo 'cannot find csv file';
}


function validate($data){
	if(!preg_match('/^([A-Za-z]+[\s]?)+$/',$data->name)){
		return false;
	}
	if(!preg_match('/\b([1-9][0-9]?|[1-3][0-9]{2}|400)\b/',$data->ID)){
		return false;
	}
	if(!preg_match('/(0[1-9]|1[012])[\/](0[1-9]|[12][0-9]|3[01])[\/](19|20)\d\d/',$data->joindate)){
		return false;
	}
	if(!preg_match('/(0[1-9]|1[012])[\/](0[1-9]|[12][0-9]|3[01])[\/](19|20)\d\d/',$data->enddate)){
		return false;
	}
	if(!preg_match('/\b([89][0-9]{3}|[1-9][0-9]{4}|100000)\b/',$data->salary)){
		return false;
	}
	if(!preg_match('/^(\s*[\+#]*\w\.?[\+#]*\w?\.?[\+#]*\s*,?)?(\s*[\+#]*\w\.?[\+#]*\w?\.?[\+#]*\s*,?)*$/',$data->skills)){
		return false;
	}
	if($data->payscale !== '8000-15000' && $data->payscale !== '15000-25000' && $data->payscale !== '25000-40000' && $data->payscale !== '40000-100000'){
		return false;
	}

	return true;
}

function prepareSQL($resource){
	$conn = connect($_SESSION['username'],$_SESSION['password'],'ORCL');
	$finalResult = array();
	foreach ($resource as $key => $value) {
		# code...
		if($_SESSION['prefix'])
			$sql = 'BEGIN '.$_SESSION['prefix'].'.update_employee(:setclause, :temp_minval, :temp_maxval, :whereclause); END;';
		else
			$sql = 'BEGIN update_employee(:setclause, :temp_minval, :temp_maxval, :whereclause); END;';

		$rowData = new stdClass();

		$ID = $value['ID'];
		$name = $value['NAME'];
		$joindate = $value['JOINDATE'];
		$payscale = $value['PAYSCALE'];
		$salary = $value['SALARY'];
		$skills = $value['SKILLS'];
		$enddate = $value['ENDDATE'];

		$rowData->ID = $value['ID'];
		$rowData->name = $value['NAME'];
		$rowData->joindate = $value['JOINDATE'];
		$rowData->payscale = $value['PAYSCALE'];
		$rowData->salary = $value['SALARY'];
		$rowData->skills = $value['SKILLS'];
		$rowData->enddate = $value['ENDDATE'];

		if(!validate($rowData)){
			$finalResult[$rowData->ID] = false;
			continue;
		}

		$setClause = 'set PAYSCALE = \''.$payscale.'\', ENDDATE = \''.$enddate.'\', SKILLS = \''.$skills.'\', SALARY = '.$salary.'';
		//$whereClause = 'and NAME = \''.$name.'\' and JOINDATE = \''.$joindate.'\' ';
		$whereClause = '';
		//echo $setClause."<br>";
		//echo $whereClause."<br>";


		$stmt = oci_parse($conn,$sql);

		//  Bind the input parameter
		oci_bind_by_name($stmt,':whereclause',$whereClause,200,SQLT_CHR);

		//  Bind the input parameter
		oci_bind_by_name($stmt,':setclause',$setClause,200,SQLT_CHR);

		//  Bind the input parameter
		oci_bind_by_name($stmt,':temp_minval',$ID,200,SQLT_INT);

		//  Bind the input parameter
		oci_bind_by_name($stmt,':temp_maxval',$ID,200,SQLT_INT);

		//oci_execute($stmt);
		$result = oci_execute($stmt);
		$finalResult[$rowData->ID] = $result;


		//$stid = oci_parse($conn, 'SELECT * FROM output_employee order by id');
		//oci_execute($stid);
	}
	$json = json_encode((object)$finalResult);
	echo $json;
}
?>