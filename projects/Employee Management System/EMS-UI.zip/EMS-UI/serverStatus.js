function serverStatusHandlers() {
	var ajaxRequest1;
	var ajaxRequest2;
	var ajaxRequest3;
	var ajaxRequest4;

	$('div.statusButtons button').click(function(event) {
		/* Act on the event */
		var $this = $(this);
		var link = $this.text();


		var $helpTextDiv = $this.parent('div').siblings('div');
		$this
			.text('Processing...')
			.attr('disabled', true);
		$helpTextDiv
			.fadeIn('fast', function() {

			})
			.removeClass('alert-info')
			.addClass('alert')
			.addClass('alert-info')
			.text('Connecting to ' + link + ' server... ')
			.append('<img src=\'spinner.gif\'>');

		if (link === 'Los Angeles') {
			ajaxRequest1 = getAjaxObject();
			var ajaxRequest = ajaxRequest1;
		}


		if (link === 'Goa') {
			ajaxRequest2 = getAjaxObject();
			var ajaxRequest = ajaxRequest2;
		}

		if (link === 'Delhi') {
			ajaxRequest3 = getAjaxObject();
			var ajaxRequest = ajaxRequest3;
		}

		if (link === 'Mumbai') {
			ajaxRequest4 = getAjaxObject();
			var ajaxRequest = ajaxRequest4;
		}



		ajaxRequest.onreadystatechange = function() {
			if (ajaxRequest.readyState == 4) {
				if (ajaxRequest.responseText.indexOf("{'redirect':'true'}") >= 0) {
					window.location.href = 'http://localhost/EMS-UI/login.php?expire=true';
					return;
				}

				// if(ajaxRequest.responseText.indexOf('Server is up and running.')>=0){
				// 	console.log('macthed');
				// 	$helpTextDiv.removeClass('alert-danger').removeClass('alert-error').removeClass('alert-info').addClass('alert-success');
				// }
					
				// else if(ajaxRequest.responseText.indexOf('Cannot find server entry. Please contact adminstrator')>=0){
				// 	$helpTextDiv.removeClass('alert-danger').removeClass('alert-error').removeClass('alert-info').addClass('alert-danger');
				// }else if(ajaxRequest.responseText.indexOf('Cannot find server entry. Please contact adminstrator')>=0){
				// 	$helpTextDiv.removeClass('alert-danger').removeClass('alert-error').removeClass('alert-info').addClass('alert-error');
				// }
				//redirectHelper(ajaxRequest);
				$helpTextDiv
					.css('display', 'inline-block')
					.text(ajaxRequest.responseText);
				$this
					.text(link)
					.attr('disabled', false);
			}
		}
		ajaxRequest.open("GET", "ping.php?location=" + link + "&ajax=true", true);
		ajaxRequest.send(null);

	});
}