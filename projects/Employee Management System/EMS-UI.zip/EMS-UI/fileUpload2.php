<?php
include('base.php');
//&& isset($_SESSION('username') && isset($_SESSION['password'])




checkActivity($_GET);

$_SESSION['LAST_ACTIVITY'] = time(); 

if(isset($_SESSION['loggedIn'])){
  checkPrivileges('update');
?>

<div class="panel panel-default">
    <div class="panel-heading">
      <div><h3 class="panel-title">Update File</h3></div>
      <button id='updateBackButton' class='btn btn-default btn-xs'>Back</button>
    </div>
    <div class="panel-body">
          <!-- Button to select & upload files -->
          <button class="btn btn-primary fileinput-button" id='selectFile'>
            <span>Select files...</span>
            <!-- The file input field used as target for the file upload widget -->
            <input id="fileupload" type="file" name="files" single>
          </button>
          
          
          <!-- The global progress bar -->
          <!--   <p>Upload progress</p>
          <div id="progress" class="progress progress-bar-warning progress-striped progress-active">
            <div class="progress-bar"></div>
          </div> -->
          <p>Upload progress</p>
          <div class="progress progress-striped active" id='progress'>
            <div class="progress-bar"  role="progressbar" aria-valuemin="0" aria-valuemax="100">
              <span class="sr-only">0% Complete</span> <!-- screen readers only -->
            </div>
          </div>
            
          <!-- The list of files uploaded -->
          <p>Files uploaded:</p>
          <ul id="files"></ul>      
      <button class='btn btn-primary' id='processFile'>Update</button>
    </div>
</div>  
<?php
}else{
  redirectToLoginPage();
}
?>
  
  
  
