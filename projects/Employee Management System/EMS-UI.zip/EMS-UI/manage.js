var activeContainer = "search";
var obj = {};

function redirectHelper(ajaxRequest){
	if(ajaxRequest.status == 302)
		redirect();
}

var validationData = {
	name: true,
	empID: true,
	empID2: true,
	salary: true,
	skills: true,
	// joiningDate: true,
	// leavingDate: true,
	allow: function() {
		if (name && empID && empID2 && salary && joiningDate)// && leavingDate)
			return true;
		else
			return false;
	},
	reset: function() {
		name = empID2 = empID = salary = true;//joiningDate = leavingDate = true;
	}
}

function clearInfo(id) {

	$this = $('#' + id);

	if ($this.val() === '') {
		$this
			.removeClass('inputInvalid')
			.parent('div').siblings('div').children('span')
			.text('')
			.removeClass('helpText-invalidated')
			.removeClass('helpText-info')
			.removeClass('helpText-validated');
		//	console.log('empty');
		return;

	}

	if (!helpTexts[id].regex.test($this.val())) {
		$this
			.parent('div').siblings('div').children('span')
			.text(helpTexts[id].invalid)
			.removeClass()
			.addClass('helpText-invalidated');

		$this.addClass('inputInvalid');
		console.log('invalid');
	} else {

		var id = $this.attr('id');

		$this
			.parent('div').siblings('div').children('span')
			.text(helpTexts[id].valid)
			.removeClass()
			.addClass('helpText-validated');
		$this
			.removeClass('inputInvalid');

		//	console.log('valid');
	}
}


function checkIDRange() {

	$from = $('#empID');
	$to = $('#empID2');

	clearInfo($from.attr('id'));
	clearInfo($to.attr('id'));

	if (parseInt($from.val()) > parseInt($to.val())) {
		console.log('error');
		$this = $from;

		$this
			.parent('div').siblings('div').children('span')
		// .text(helpTexts[$this.attr('id')].invalid)
		.text('To ID is lesser than From ID!')
			.removeClass()
			.addClass('helpText-invalidated');

		$this.addClass('inputInvalid');

		$this = $to;

		$this
			.parent('div').siblings('div').children('span')
		// .text(helpTexts[$this.attr('id')].invalid)
		.text('To ID is lesser than From ID!')
			.removeClass()
			.addClass('helpText-invalidated');

		$this.addClass('inputInvalid');
	} // from should be less than to id
}

function checkDate() {
	$join = $('#joiningDate');
	$leave = $('#leavingDate');

	if ($join.val() === '' || $leave.val() === '') {
		var id = $join.attr('id');
		$this = $join;
		$this
			.parent('div').siblings('div.col-lg-1').children('button').css('display', 'none');
		$this
			.parent('div').siblings('div').children('span')
			.text(helpTexts[id].valid)
			.removeClass()
			.addClass('helpText-validated');
		$this
			.removeClass('inputInvalid');


		var id = $leave.attr('id');
		$this = $leave;
		$this
			.parent('div').siblings('div.col-lg-1').children('button').css('display', 'none');
		$this
			.parent('div').siblings('div').children('span')
			.text(helpTexts[id].valid)
			.removeClass()
			.addClass('helpText-validated');
		$this
			.removeClass('inputInvalid');
	} else {
		if ($join.val() >= $leave.val()) {
			$this = $join;

			$this
				.parent('div').siblings('div').children('span')
			// .text(helpTexts[$this.attr('id')].invalid)
			.text('Join Date is newer than Leave Date!')
				.removeClass()
				.addClass('helpText-invalidated');

			$this.addClass('inputInvalid');

			$this = $leave;

			$this
				.parent('div').siblings('div').children('span')
			// .text(helpTexts[$this.attr('id')].invalid)
			.text('Join Date is newer than Leave Date!')
				.removeClass()
				.addClass('helpText-invalidated');

			$this.addClass('inputInvalid');
		} // join date has to be greater than leave date
	}
}

var helpTexts = {
	name: {
		info: 'Enter a valid name',
		invalid: 'Please correct the entered value',
		valid: 'Looks great!',
		regex: /^([A-Za-z]+[\s]?)+$/
	},

	empID: {
		info: 'Enter a valid number between 1 and 400',
		invalid: 'Please correct the entered value',
		valid: 'Looks great!',
		regex: /\b([1-9][0-9]?|[1-3][0-9]{2}|400)\b/
	},


	empID2: {
		info: 'Enter a valid number between 1 and 400',
		invalid: 'Please correct the entered value',
		valid: 'Looks great!',
		regex: /\b([1-9][0-9]?|[1-3][0-9]{2}|400)\b/
	},

	salary: {
		info: 'Enter a valid number between 8000 and 100000',
		invalid: 'Please correct the entered value',
		valid: 'Looks great!',
		regex: /\b([89][0-9]{3}|[1-9][0-9]{4}|100000)\b/
	},

	joiningDate: {
		info: 'Minimum 01/01/1900 (mm/dd/yyyy)',
		invalid: 'Please correct the entered date',
		valid: '',
		regex: /(0[1-9]|1[012])[- \/.](0[1-9]|[12][0-9]|3[01])[- \/.](19|20)\d\d/
	},

	leavingDate: {
		info: 'Minimum 01/01/1900 (mm/dd/yyyy)',
		invalid: 'Please correct the entered date',
		valid: '',
		regex: /(0[1-9]|1[012])[- \/.](0[1-9]|[12][0-9]|3[01])[- \/.](19|20)\d\d/
	},
	skills: {
		info: 'Enter skills separated by commas',
		invalid: 'Cannot validate input',
		valid: 'Looks great!',
		regex: /^(\s*[\+#]*\w\.?[\+#]*\w?\.?[\+#]*\s*,?)?(\s*[\+#]*\w\.?[\+#]*\w?\.?[\+#]*\s*,?)*$/
	}
}



function onLoadPrepareSearch(){
	var ajaxRequest = getAjaxObject();

	$('#' + activeContainer).fadeOut('fast', function() {
		ajaxRequest.onreadystatechange = function() {
			if (ajaxRequest.readyState == 4) {
				if (ajaxRequest.responseText.indexOf("{'redirect':'true'}") >= 0) {
					window.location.href = 'http://localhost/EMS-UI/login.php?expire=true';
					return;
				}
				//console.log(ajaxRequest);
				//redirectHelper(ajaxRequest);
				$('#search')
					.html(ajaxRequest.responseText)
					.fadeIn('fast');
				activeContainer = 'search';
				searchHandlers();
			}
		}
		ajaxRequest.open('GET', 'search.php?ajax=true', true);
		ajaxRequest.send(null);
	});
}
var intent;
function searchHandlers(){
	$("#searchSubmit").click(function(event) {

		$this = $(this);

		intent = $this.data('for');
		if(intent === 'update'){
			$('#responseText').hide();
		}
		var allow = 1;
		$('form input').each(function(index, el) {
			if ($(this).hasClass('inputInvalid'))
				allow = allow & false;
		});

		if (!allow) {
			showAlert();
			return;
		} else {

			$('div#searchError').fadeOut('fast', function() {
				console.log('after fading out');
			});

		}
		var clause = "";
		var data = prepareInputs();

		if (validateInput(data)) {

			var minval = 1;
			var maxval = 400;
			var salary;

			clause += 'WHERE';
			if (data.name.length) {
				clause += " NAME = \'" + data.name + "\' and ";
			}

			if (!obj.empID.length == 0) {
				if (isNaN(parseInt(obj.empID, 10))) {
					alert("Enter a number in the Employee id from");
					return;
				} else {
					minval = parseInt(obj.empID, 10);
				}
			}

			if (!obj.empID2.length == 0) {
				if (isNaN(parseInt(obj.empID2, 10))) {
					alert("Enter a number in the Employee id to");
					return;
				} else {
					maxval = parseInt(obj.empID2, 10);
				}
			}

			if (maxval < minval) {
				alert("Employee To should be greater than Employee From");
				return;
			}

			if (!obj.salary.length == 0) {
				if (isNaN(parseInt(obj.salary, 10))) {
					alert("Enter a number in the salary field");
					return;
				} else {
					salary = parseInt(obj.salary, 10);
					clause += " SALARY = " + salary + " and ";
				}
			}

			if (data.payBand.length) {
				if (data.payBand !== 'Not Specified')
					clause += " PAYSCALE = \'" + data.payBand + "\' and ";
				else {
					// do nothing
				}
			}


			// if (data.joiningDate.length) {
			// 	var date = obj.joiningDate;
			// 	var array = date.split('/');

			// 	var test = array[0] + '/' + array[1] + '/' + array[2];

			// 	clause += " JOINDATE = \'" + test + "\' and ";
			// }


			// if (data.leavingDate.length) {
			// 	if (new Date(data.leavingDate).getTime() <= new Date(data.joiningDate).getTime()) {
			// 		alert("Joining Date is greater than leaving date");
			// 		return false;
			// 	} else {
			// 		var date = obj.leavingDate;
			// 		var array = date.split('-');

			// 		var test = array[1] + '/' + array[0] + '/' + array[2];

			// 		clause += " ENDDATE = \'" + test + "\' and ";
			// 	}
			// }
			if (data.skills.length) {
				//	clause += "SKILLS = \'"+data.skills+"\' and ";	
				clause += ' (';

				var clean = data.skills.replace(/[\s]/g, '');
				var array = clean.split(',');

				for (var i = 0; i < array.length; i++) {
					clause += " SKILLS like ";
					clause += "\'%" + array[i] + "%\' or ";
				}

				clause = clause.substr(0, clause.lastIndexOf(' or'));

				clause += ') and';

			}


			//clause = clause.substr(0,clause.lastIndexOf(" and"));
			//console.log(clause.lastIndexOf(' and'));
			console.log(clause);
			// console.log(minval);
			// console.log(maxval);
			if (data.location.length) {
				if (data.location !== "All Locations") {

					var site;

					if (data.location === 'Los Angeles')
						site = 'ankur';
					if (data.location === 'Mumbai')
						site = 'surya';
					if (data.location === 'Delhi')
						site = 'sahil';
					if (data.location === 'Goa')
						site = 'pravin';

					clause += ' id<=' + maxval + ' and id >=' + minval + ' and';
					clause = clause.substr(0,clause.lastIndexOf(" and"));
					postData(clause, minval, maxval, site);

					animateToSearch();
					//	clause += "LOCATION = \'"+data.location+ "\' and ";		
				} else {
					// do nothing
					// alert user that we are fetching all tuples.
					if (clause === 'WHERE' && minval == 1 && maxval == 400) {
						console.log('matched where');
						$('#myModal').modal('show');

						$('#confirmQuery').click(function(event) {
							/* Act on the event */
							console.log('confirmed query');
							$('#myModal').modal('hide');
							postData(clause, minval, maxval, false);
							animateToSearch();
							postData(clause, minval, maxval, false);
						});

						return;
					}
					animateToSearch();
					postData(clause, minval, maxval, false);
				}
			}


		}
	});
	$('#resetForm').click(function(event) {
		/* Act on the event */
		$('div#searchError').fadeOut('fast', function() {
			console.log('after fading out');
		});


		event.preventDefault();
		$('form input').each(function(index, el) {
			$this = $(this);
			$this
				.val('');
			$this
				.parent('div').siblings('div').children('span')
				.text('')
				.removeClass()
				.addClass('helpText');
			$this
				.removeClass('inputInvalid');
		});

		$('form #location').val('All Locations');
		$('form #payBand').val('Not Specified');

	});

	$(document).on('click','button.resetDate',function(event){
		event.preventDefault();
		console.log('listening');
		var handle = $(this).parent('div').siblings().eq(0).children('input');
		$.datepicker._clearDate(handle);
		$(this).css('display', 'none');
	});

	// $('button.resetDate').click(function(event) {

	// 	/* Act on the event */
		
	// });


	$("#joiningDate").datepicker({
		changeMonth: true,
		changeYear: true,
		maxDate: 0,
		minDate: '01/01/1900',
		showAnim: "fadeIn",
		yearRange: '1900:+00'
	});

	$("#leavingDate").datepicker({
		changeMonth: true,
		changeYear: true,
		showAnim: "fadeIn",
		minDate: '01/01/1900',
		maxDate: 0,
		yearRange: '1900:+00'
	});


	$('div.form-group input').focusin(function(event) {

		/* Act on the event */

		event.preventDefault();
		$this = $(this);
		var id = $this.attr('id');
		if (id === 'joiningDate' || id === 'leavingDate') {
			$this
				.parent('div').siblings('div.col-lg-1').children('button').css('display', 'inline-block');
		}
		if (id) {
			$this
				.parent('div').siblings('div').children('span')
				.text(helpTexts[id].info)
				.removeClass()
				.addClass('helpText-info');
		}
	});

	$('div.form-group input').focusout(function(event) {

		/* Act on the event */
		event.preventDefault();
		$this = $(this);
		var id = $this.attr('id');
		if (id === 'joiningDate' || id === 'leavingDate') {
			console.log('focusing out of date');
			checkDate();
			if (!$this.val()) {

				$this
					.parent('div').siblings('div.col-lg-1').children('button').css('display', 'none');
				$this
					.removeClass('inputInvalid')
					.parent('div').siblings('div').children('span')
					.text('')
					.removeClass('helpText-invalidated')
					.removeClass('helpText-info')
					.removeClass('helpText-validated');
				checkDate();
			}
		}
		if (!$this.val()) {
			$this
				.removeClass('inputInvalid')
				.parent('div').siblings('div').children('span')
				.text('')
				.removeClass('helpText-invalidated')
				.removeClass('helpText-info')
				.removeClass('helpText-validated');
		} else {
			if (!helpTexts[id].regex.test($this.val())) {
				$this
					.parent('div').siblings('div').children('span')
					.text(helpTexts[id].invalid)
					.removeClass()
					.addClass('helpText-invalidated');

				$this.addClass('inputInvalid');
			} else {
				var id = $this.attr('id');

				$this
					.parent('div').siblings('div').children('span')
					//.text(helpTexts[id].valid)
					.removeClass()
					//.addClass('helpText-validated');
					.addClass('glyphicon')
					.addClass('glyphicon-ok')
					.addClass('iconGreen')
					.text('');
				$this
					.removeClass('inputInvalid');

			}
		}
		if (id === 'empID' || id === 'empID2')
			checkIDRange();
	});


	$('input[readonly=\'true\']').change(function(event) {
		/* Act on the event */
		console.log('fired');
		event.preventDefault();
		$this = $(this);
		var id = $this.attr('id');
		if (!$this.val()) {

			$this
				.removeClass('inputInvalid')
				.parent('div').siblings('div').children('span')
				.text('')
				.removeClass('helpText-invalidated')
				.removeClass('helpText-info')
				.removeClass('helpText-validated');
		} else {
			if (!helpTexts[id].regex.test($this.val())) {
				$this
					.parent('div').siblings('div').children('span')
					.text(helpTexts[id].invalid)
					.removeClass()
					.addClass('helpText-invalidated');

				$this.addClass('inputInvalid');
			} else {
				var id = $this.attr('id');
				$this
					.parent('div').siblings('div.col-lg-1').children('button').css('display', 'none');
				$this
					.parent('div').siblings('div').children('span')
					.text(helpTexts[id].valid)
					.removeClass()
					.addClass('helpText-validated');
				$this
					.removeClass('inputInvalid');

			}
		}
		checkDate();
	});
}

$(document).ready(function() {
	onLoadPrepareSearch();
});

$(window).bind("beforeunload", function() {
	logout();
});

function getAjaxObject() {
	try {
		// create XMLHttpRequest for firefox, safari, opera
		ajaxObject = new XMLHttpRequest();
	} catch (e) {
		try {
			// create XMLHttpRequest for IE 6.0+
			ajaxObject = new ActiveXObject('Msxml2.XMLHTTP');
		} catch (e) {
			try {
				// create XMLHttpRequest for IE 6.0+
				ajaxObject = new ActiveXObject('Microsoft.XMLHTTP');
			} catch (e) {
				alert('Your browser is not supporting AJAX');
			}
		}
	}
	return ajaxObject;
}

function create(string) {
	return document.createElement(string);
}

function createTable(object,update) {

	
	if (jQuery.isEmptyObject(object)) {
		document.querySelectorAll(".resultsHeader")[0].style.display = 'block';
		document.querySelectorAll("div#responseText div.error")[0].innerHTML = "<div class=\"alert alert-warning\">Empty response received</div>";

		var table = document.querySelectorAll("#responseText table")[0];
		table.innerHTML = "";
	} else {

		if(update){
			$('#responseText').fadeIn('fast', function() {
			});
		}
		

		document.querySelectorAll("div#responseText div.error")[0].innerHTML = "";
		if(update)
			$('#updateInfo').show();

		var table = document.querySelectorAll("#responseText table")[0];

		table.innerHTML = "";
		$('#responseText table').fadeIn('fast', function() {
			
		});

		var thead = create('thead');
		thead.appendChild(create('tr'));

		var tbody = create('tbody');


		// create the table head
		var theadTR = thead.children[0];
		var td = create('td');

		// if(update){
		// 	td = create('td');
		// 	$(td).html('<input type="checkbox" class="global-check">');
		// 	theadTR.appendChild(td);
		// }

		for (columns in object[0]) {
			td = create('td');
			$(td).text(columns);
			//td.innerText = columns;
			//console.log(td);
			theadTR.appendChild(td);
		}

		if (update) {
			td = create('td');
			$(td).html('<button class="btn btn-xs btn-primary global-update-button">Edit</button>');
			theadTR.appendChild(td);
		}

		if (update) {
			td = create('td');
			$(td).html('<button class="btn btn-xs btn-primary global-reset-button">Reset</button>');
			theadTR.appendChild(td);
		}

		if(update){
			$('#submitUpdates').show();
		}

		// create the table body
		var tr;
		var td;
		if(update){
			for (item in object) {
				tr = create('tr');
				td = create('td');
				// if (update) {
				// 	td = create('td');
				// 	$(td).html('<input type="checkbox" class="item-check">');
				// 	tr.appendChild(td);
				// }

				for (columns in object[item]) {
					td = create('td');
					$(td).text(object[item][columns]);
					$(td).data('old',object[item][columns]);
					tr.appendChild(td);
				}
				if (update) {
					td = create('td');
					$(td).html('<button class="btn btn-xs btn-info item-update-button">Edit</button>');
					tr.appendChild(td);
				}

				if (update) {
					td = create('td');
					$(td).html('<button class="btn btn-xs btn-info item-reset-button">Reset</button>');
					tr.appendChild(td);
				}

				tbody.appendChild(tr);

				

			}
		}else{
			for (item in object) {
				tr = create('tr');
				td = create('td');
				
				for (columns in object[item]) {
					td = create('td');
					$(td).text(object[item][columns]);
					tr.appendChild(td);
				}
				
				tbody.appendChild(tr);
			}
		}
		

		table.appendChild(thead);
		table.appendChild(tbody);
		


		document.querySelectorAll(".resultsHeader")[0].style.display = 'block';
	}

}

var ajaxRequest;

function postData(clause, minval, maxval, location) {
	ajaxRequest = getAjaxObject();
	ajaxRequest.onreadystatechange = function() {
		if (ajaxRequest.readyState == 4) {

			if (ajaxRequest.responseText.indexOf("{'redirect':'true'}") >= 0) {
				console.log('found match');
				window.location.href = 'http://localhost/EMS-UI/login.php?expire=true';
				return;
			}

			//redirectHelper(ajaxRequest);
			console.log('invoked');
			$('#searchSubmit').text('Search').attr('disabled', false);
			//console.log(ajaxRequest.responseText);

			if (ajaxRequest.responseText.indexOf('{') == 0) {
				var response = JSON.parse(ajaxRequest.responseText);
				setTimeout(function() {
					$('#delay').fadeOut('fast', function() {
						var target = $('#searchSubmit').data('href'),
							$target = $(target);
						$('html, body').stop().animate({
							'scrollTop': $target.offset().top
						}, 300, 'swing', function() {
							window.location.hash = target;
						});
					});
					if (typeof(response) === 'object') {
						if(intent === 'update')
							createTable(response,true);
						else
							createTable(response,false);
					}
				}, 1500);

			} else {

				document.querySelectorAll(".resultsHeader")[0].style.display = 'block';

				var table = document.querySelectorAll("#responseText table")[0];
				table.innerHTML = "";
				$('#delay').fadeOut('fast', function() {
					var target = $('#searchSubmit').data('href'),
						$target = $(target);
					$('html, body').stop().animate({
						'scrollTop': $target.offset().top
					}, 300, 'swing', function() {
						window.location.hash = target;
					});
				});
				document.querySelectorAll("div#responseText div.error")[0].innerHTML = "<div class=\"alert alert-danger\">Unexpected response received. Please contant the administrator</div>";
				console.log(ajaxRequest.responseText);
			}
		}
	}
	//console.log("?data=" + clause + "&minval=" + minval + "&maxval=" + maxval);	
	console.log(clause);
	clause = encodeURIComponent(clause);
	if (location) {
		ajaxRequest.open("GET", "select.php?data=" + clause + "&minval=" + minval + "&maxval=" + maxval + "&location=" + location + "&ajax=true", true);
	} else {
		ajaxRequest.open("GET", "select.php?data=" + clause + "&minval=" + minval + "&maxval=" + maxval + "&ajax=true", true);
	}

	ajaxRequest.send(null);

	//document.querySelectorAll(".resultsHeader")[0].style.display = 'block';

	$('#delay').fadeIn('fast', function() {
		$('#cancelRequest').click(function(event) {
			
			/* Act on the event */
			ajaxRequest.abort();
			$('#delay')
				.html('Cancelling Request... Please Wait.')
				.append('<img src=\'spinner.gif\'>');

			$('#responseText div.error').fadeOut('0', function() {
			
			});

			setTimeout(function() {
				$('#delay')
					.html('The request has been cancelled');
				$('#searchSubmit').text('Search').attr('disabled', false);
				$('#delay').fadeOut('200', function() {
					console.log('fade oout from delay');
				});
				$("html, body").animate({
					scrollTop: 0
				}, 500);
			}, 1000);

		});
	}).html('Please wait while your query is being processed<button class=\'btn btn-xs btn-warning\' id=\'cancelRequest\'>Cancel Request</button>');

	var img = document.createElement('img');
	img.setAttribute('src', 'spinner.gif');

	//document.querySelectorAll("#delay p")[0].insertAdjacentElement('beforeend',img);
	$('#delay').append(img);
}



function validateInput(data) {

	if (data.name.length || data.empID.length || data.location.length || data.payBand.length /*|| data.joiningDate.length || data.leavingDate.length*/ || data.skills.length) {
		return true;
	} else {
		window.alert("Please enter atleast one field");
		return false;
	}
}



function prepareInputs() {

	obj.name = document.getElementById("name").value;
	obj.empID = document.getElementById("empID").value;
	obj.empID2 = document.getElementById("empID2").value;
	obj.salary = document.getElementById('salary').value;
	obj.location = document.getElementById("location").value;
	obj.payBand = document.getElementById("payBand").value;
	//obj.joiningDate = document.getElementById("joiningDate").value;
	//obj.leavingDate = document.getElementById("leavingDate").value;
	obj.skills = document.getElementById("skills").value;

	console.log(obj);
	return obj;
}

function showAlert() {
	$('div#searchError').fadeIn('fast', function() {
		console.log('after fading in');
	});
}

function animateToSearch() {

	$this = $('#searchSubmit');

	$this.text('Processing...');
	$this.attr('disabled', true);

	var target = $this.data('href'),
		$target = $(target);

	$('#resultsHeader').fadeIn('fast', function() {
		$('html, body').stop().animate({
			'scrollTop': $target.offset().top
		}, 300, 'swing', function() {
			window.location.hash = target;
		});
	});
}



$("a.list-group-item").click(function() {
	var $this = $(this);
	$this
		.addClass('active')
		.siblings('a.list-group-item')
		.removeClass('active');

	var temp = $this.data("link");

	if (temp !== activeContainer) {
		//console.log('fading');
		$('#' + activeContainer).fadeOut('200', function() {

			$('#' + temp)
				.html('').show();
			var ajaxRequest = getAjaxObject();
			ajaxRequest.onreadystatechange = function() {
				if (ajaxRequest.readyState == 4) {
					if (ajaxRequest.responseText.indexOf("{'redirect':'true'}") >= 0) {
						console.log('pattern matched');
						window.location.href = 'http://localhost/EMS-UI/login.php?expire=true';
						return;
					}
					//redirectHelper(ajaxRequest);
					console.log(ajaxRequest.responseText);
					$('#' + temp).html(ajaxRequest.responseText);

					activeContainer = temp;
					handlers[temp].handler();
				}
			}
			ajaxRequest.open('GET', temp + '.php?ajax=true', true);
			ajaxRequest.send(null);
		});
	}
});


$("ul.nav li").click(function() {
	$(this)
		.addClass('active')
		.siblings('ul.nav li')
		.removeClass('active');
});

function logout() {
	ajaxRequest = getAjaxObject();
	// ajaxRequest.onreadystatechange = function(){
	// 	if(ajaxRequest.readyState == 4){
	// 		//console.log(ajaxRequest.responseText);
	// 		//window.location = "login.html";
	// 	}
	// }
	ajaxRequest.open("GET", "logout.php", true);
	ajaxRequest.send(null);
	setTimeout(function() {
		$(location).attr('href', 'login.php');
	}, 100);
}

document.getElementById("logout").onclick = logout;

var handlers = {
	'search' : {
		handler: searchHandlers
	},
	'update' : {
		handler: updateHandlers
	},
	'delete' : {
		handler: deleteHandlers
	},
	'serverStatus':{
		handler: serverStatusHandlers
	},
	'manageUsers':{
		handler: manageUsersHandlers
	},
	'restore':{
		handler: restoreHandlers
	}
}