function fileUploadHandlers() {
    // When the server is ready...
   
        'use strict';

        // Define the url to send the image data to
        var url = 'files.php';

        // Call the fileupload widget and set some parameters
        $('#downloadSample').click(function(event){
            event.preventDefault();
        });

        $('#fileupload').fileupload({
            url: url,
            dataType: 'json',
            done: function(e, data) {
                // Add each uploaded file name to the #files list
                $.each(data.result.files, function(index, file) {
                    $('<li/>').text(file.name).appendTo('#files');
                });
            },
            progressall: function(e, data) {
                // Update the progress bar while files are being uploaded
                var progress = parseInt(data.loaded / data.total * 100, 10);
                var $this = $('#progress .progress-bar');
                $this.css(
                    'width',
                    progress + '%'
                );
                $('#progress span').text(progress + '% Complete');
                if (progress == 100){
                    $('#progress').removeClass('active');
                    $('#selectFile').attr('disabled', true);
                }
            }
        });

        $('#updateBackButton').click(function(event) {
            /* Act on the event */
            $('#uploadFileDiv').fadeOut('fast', function() {
                $('#choicesPanel').fadeIn('fast', function() {
                    
                });    
            });
        });
}