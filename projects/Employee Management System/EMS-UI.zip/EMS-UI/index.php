<?php
include('base.php');

//&& isset($_SESSION('username') && isset($_SESSION['password'])

// if(isset($_SESSION['LAST_ACTIVITY'])){
//   echo $_SESSION['LAST_ACTIVITY'];
// }else{
//   echo "Not set";
// }

checkActivity($_GET);

if(isset($_SESSION['loggedIn']) ){
?>
<!DOCTYPE html>
<html>
  <head>
    <title>EMS Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
    <link href="jquery-ui.css" rel="stylesheet" media="screen">
    <link href="style.css" rel="stylesheet" media="screen">
    <link href="delete.css" rel="stylesheet" media="screen">
    <link href="restore.css" rel="stylesheet" media="screen">
    <link href="bootstrap/css/upload.css" rel="stylesheet" media="screen">
    
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="../../assets/js/html5shiv.js"></script>
    <script src="../../assets/js/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <!-- <meta class='permissions' data-permissions=''> -->
    <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#">Insta-EMS</a>
      </div>
      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav">
          <li ><a href="index.php">Home</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li><a href='index.php'>Welcome! <?php echo$_SESSION['username']?></a></li>
          <li><button class='btn btn-default' href="#" id="logout">Logout</button></li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </nav>
      <div class="pageContainer">
        
        <div class="list-group">
          <a href="#" class="list-group-item active" data-link="search">
          Search
          </a>
          <!-- <a href="#" class="list-group-item" data-link="skillSearch">Skill Search</a> -->
          <?php 
    if($_SESSION['priv'] > 1)
      echo '<a href="#" class="list-group-item" data-link="update">Update</a>
           <a href="#" class="list-group-item" data-link="delete">Delete</a>
           <a href="#" class="list-group-item" data-link="restore">Restore</a>';
     ?><a href="#" class="list-group-item" data-link="serverStatus">Server Status</a>
        </div>
        <div class="mainContent well">
          <div id="search">
          </div>
          <div id="manageUsers">
          </div>
          <div id="update">
          </div>
          <div id="delete">
          </div>
          <div id="serverStatus">
          </div>
          <div id="restore">
          </div>
        </div>
      </div>
      <script src="restore.js"></script>
      <script src="manualUpdate.js"></script>
      <script src="jquery-1.10.2.js"></script>
      <script src="jquery-ui.js"></script>
      <script src="bootstrap/js/bootstrap.js"></script>
      <script src="jquery.iframe-transport.js"></script>
      <script src="jquery.fileupload.js"></script>
      <script src="delete.js"></script>
      <script src="uploadFinal/uploadFile.js"></script>
      <script src="serverStatus.js"></script>
      <script src="update.js"></script>
      <script src="uploadFinal/jquery.form.js"></script>
      
      <script src="manageUsers.js"></script>
      <script src="manage.js"></script>
      
    </body>
  </html>
  
  <?php
  }else{
    redirectToLoginPage();
  }
  ?>