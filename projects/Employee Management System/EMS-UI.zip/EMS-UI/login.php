<?php
  include('base.php');

  //var_dump($_SESSION);
  if(isset($_SESSION['loggedIn']) && $_SESSION['loggedIn']){
    header('Location:index.php');
  }else{
?>
<!DOCTYPE html>
<html>
  <head>
    <title>EMS Secure Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
    <link href="style2.css" rel="stylesheet" media="screen">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="../../assets/js/html5shiv.js"></script>
      <script src="../../assets/js/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class="globalContainer">
      <nav class="navbar navbar-inverse" role="navigation">
        <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php">Insta-EMS</a>
      </div>
      
      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav">
          <li ><a href="index.php">Home</a></li>
          <li ><a href="login.php">Login</a></li>
      </div><!-- /.navbar-collapse -->
      </nav>
      <div id="responseDiv" class="alert alert-info alert-dismissable">
        <p>Too many login attempts may get your account locked. Exercise extreme caution.</p>
      </div>
      <div class="loginDiv">  
        <h2>Secure Login</h2>
        <h4>Login to access your dashboard</h4>

        <div class="form-group">
          <input type="email" class="form-control" id="username" placeholder="Username">
        </div>

        <div class="form-group">
          <input type="password" class="form-control" id="password" placeholder="Password">
        </div>

        <button type="button" class="btn btn-info" id = "login">Login</button>
      </div>
    </div>  
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="jquery-1.10.2.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.js"></script>
    <script src="login.js"></script>
  </body>
</html>
<?php
 
}
?>




