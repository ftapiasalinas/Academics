<?php
include('base.php');

checkActivity($_GET);

$conn = connect($_SESSION['username'],$_SESSION['password'],'ORCL');

$string = 'WHERE ';
$minval = intval($_GET["id"]);


//echo $string;
//echo $minval;
//echo $maxval;
$attr = 'id';

if(isset($_SESSION['prefix']))
		$sql = 'BEGIN '.$_SESSION['prefix'].'.select_employee(:whereclause, :attr, :minval, :maxval); END;';
	else
		$sql = 'BEGIN select_employee(:whereclause, :attr, :minval, :maxval); END;';




$stmt = oci_parse($conn,$sql);

//  Bind the input parameter
oci_bind_by_name($stmt,':whereclause',$string,200,SQLT_CHR);

//  Bind the input parameter
oci_bind_by_name($stmt,':attr',$attr,200,SQLT_CHR);

//  Bind the input parameter
oci_bind_by_name($stmt,':minval',$minval,200,SQLT_INT);

//  Bind the input parameter
oci_bind_by_name($stmt,':maxval',$minval,200,SQLT_INT);

oci_execute($stmt);


if(isset($_SESSION['prefix']))
	$stid = oci_parse($conn, 'SELECT * FROM '.$_SESSION['prefix'].'.output_employee order by id');
else
	$stid = oci_parse($conn, 'SELECT * FROM output_employee order by id');

oci_execute($stid);

$resultArray = array();

while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
    array_push($resultArray,$row);
}

$json = json_encode((object)$resultArray);
echo $json;

?>

