function validateOnSubmit(){
	var a = validateName();
	var b = validateID();
	var c = validateTerms();
	var d = validateLocation();	
	if(a && b && c && d){
		document.getElementById('result').innerHTML = "<p>Validated Successfully</p>";
		document.getElementById('result').style.display = 'block';
	}else{
		document.getElementById('result').style.display = 'block';
		document.getElementById('result').innerHTML = "<p>Validation Failed</p>";
	}
}


function validateName(){
	if(document.getElementById('textInput').value){

	}
	var name = document.getElementById('textInput').value;
	var regex  = /^([A-Za-z]+[\s]?)+$/;
	if(!regex.test(name)){
		document.querySelectorAll('p.help-block')[0].innerHTML = "";
		document.querySelectorAll('p.help-block')[0].style.color = 'red';
		document.querySelectorAll('p.help-block')[0].innerHTML = "Cannot validate name";

		return 0;
	}else{
		document.querySelectorAll('p.help-block')[0].style.color = '#000';
		document.querySelectorAll('p.help-block')[0].innerHTML = "";
		document.querySelectorAll('p.help-block')[0].innerHTML = "<i class='icon-ok' style='color: green'></i>";
		return 1;
	}
}

function validateID(){
	var name = document.getElementById('number').value;
	var regex  = /^[\d]{1,5}$/;
	if(!regex.test(name)){
		document.querySelectorAll('p.help-block')[1].innerText = "Cannot validate ID";
		document.querySelectorAll('p.help-block')[1].style.color = 'red';
		return 0;
	}else{
		if(!(parseInt(name)<1 || parseInt(name) >99999)){
			document.querySelectorAll('p.help-block')[1].innerHTML = "";
			document.querySelectorAll('p.help-block')[1].innerHTML = "<i class='icon-ok' style='color: green'></i>";
			return 1;
		}else{
			document.querySelectorAll('p.help-block')[1].innerText = "Cannot validate ID";
			document.querySelectorAll('p.help-block')[1].style.color = 'red';
			return 0;	
		}
		
	}
}

function validateTerms(){
	var name = document.getElementById('terms').checked;
	if(!name){
		document.querySelectorAll('p.help-block')[2].style.color = 'red';
		document.querySelectorAll('p.help-block')[2].innerHTML = "Please Check This";
		return 0;
	}else{
		document.querySelectorAll('p.help-block')[2].innerHTML = "";
		document.querySelectorAll('p.help-block')[2].innerHTML = "<i class='icon-ok' style='color: green'></i>";
		return 1;
	}
}

function validateLocation(){
	var name = document.getElementById('select').value;
	if(name === '---Select---'){
		document.querySelectorAll('p.help-block')[3].innerText = "Invalid Location";
		document.querySelectorAll('p.help-block')[3].style.color = 'red';
		return 0;
	}else{
		document.querySelectorAll('p.help-block')[3].innerHTML = "";
		document.querySelectorAll('p.help-block')[3].innerHTML = "<i class='icon-ok' style='color: green'></i>";
		return 1;
	}
}

document.getElementById('button').onclick = validateOnSubmit;