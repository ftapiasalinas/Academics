
<?php
include('base.php');
//&& isset($_SESSION('username') && isset($_SESSION['password'])
checkActivity($_GET);

$_SESSION['LAST_ACTIVITY'] = time(); 
if(isset($_SESSION['loggedIn']) ){
?>
  <div class="header">
    <h2>Manage Users</h2>
  </div>
<?php
}else{
  redirectToLoginPage();
 }

?>