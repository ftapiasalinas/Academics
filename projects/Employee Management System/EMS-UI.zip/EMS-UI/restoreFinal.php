<?php
include('base.php');
checkActivity($_GET);

$confirm;
if(isset($_GET['confirm']) && $_GET['confirm'] === 'yes'){
	$confirm = true;
}else{
	$confirm = false;
}

$result = array();
$before;$after;
if($confirm){
	$conn = connect($_SESSION['username'],$_SESSION['password'],'ORCL');

	$stid = oci_parse($conn, 'truncate table employees');
		oci_execute($stid);

	$sql = 'BEGIN restore_my_data(:who); END;';
	$string = $_SESSION['prefix'];
	$stmt = oci_parse($conn,$sql);

	//  Bind the input parameter
	oci_bind_by_name($stmt,':who',$string,200,SQLT_CHR);


	if(@oci_execute($stmt)){

		$result['count'] = 0;
		
	
		$stid = oci_parse($conn, 'select * from employees');
		oci_execute($stid);

		while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
		    $result['count']++;
		}		

		// while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
		//     $after++;
		// }

		if($result['count'] > 0){
			$result['status'] = 1;	
		}else{
			$result['status'] = 0;	
		}
	}
	else{
		$result['status'] = 0;
	}

	$json = json_encode((object)$result);

	echo $json;

}else{
	$result['status'] = 2; // invalid input

	$json = json_encode((object)$result);

	echo $json;
}
//delete_employees(whereclause varchar2, minval int, maxval int)

?>

