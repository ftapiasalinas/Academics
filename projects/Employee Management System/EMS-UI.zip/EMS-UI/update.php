
<?php
include('base.php');
//&& isset($_SESSION('username') && isset($_SESSION['password'])
checkActivity($_GET);

$_SESSION['LAST_ACTIVITY'] = time(); 
if(isset($_SESSION['loggedIn']) ){
    
    checkPrivileges('update');

?>
  <div class="header">
    <h2>Update</h2>
  </div>
  <!-- <div class='alert alert-info updateHelpText'>
    <em>File Upload</em><p> Use this method to update any combination of users. Typically used to update large (more than 10) number of users. </p><br />
    <em>Manual Update</em><p> Use this method only if you have the appropriate search query. Typically used to update less than 10 users. </p><br />
  </div> -->
  <div class="panel panel-default" id='choicesPanel'>
    <div class="panel-heading">
      <h3 class="panel-title">Update Choices</h3>
    </div>
    <div class="panel-body">
      <div class="radio">
        <label>
          <input type="radio" name="optionsRadios" id="uploadFile" value="option1" checked>
          Upload a csv file containing upload parameters.
        </label>
      </div>
      <div class="radio">
        <label>
          <input type="radio" name="optionsRadios" id="manualUpdate" value="option2">
          Search for employee and update.
        </label>
      </div>
      <button class='btn btn-primary' id='updateChoiceButton'>Next</button>
    </div>
  </div>
  <div id='manualUpdateDiv'>
    
  </div>

  <div id='uploadFileDiv'>
  </div>
    
<?php
}else{
  redirectToLoginPage();
}
?>