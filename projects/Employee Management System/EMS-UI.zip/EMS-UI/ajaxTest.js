var username = 'surya';
var password = 'oracle';

function performLogin() {

	ajaxRequest = getAjaxObject();

	ajaxRequest.onreadystatechange = function() {
		if (ajaxRequest.readyState == 4) {
			console.log(ajaxRequest.responseText);
		}
	}
	username = encodeURIComponent(username);
	password = encodeURIComponent(password);


	var data = "username=" + username + "&password=" + password;
	ajaxRequest.open("POST", "ajaxTest.php", true);
	ajaxRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	ajaxRequest.timeout = 10000;
	ajaxRequest.send(data);
}