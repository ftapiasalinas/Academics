<?php
if(!empty($_SESSION['loggedIn']) && !empty($_SESSION['username']) && !empty($_SESSION['password']) && !empty($_SESSION['connectionHandle'])){
	echo "loggedIn";
}else{
	echo "loggedOut";
}
?>