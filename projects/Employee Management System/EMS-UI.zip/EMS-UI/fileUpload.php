<?php
include('base.php');
//&& isset($_SESSION('username') && isset($_SESSION['password'])

checkActivity($_GET);

$_SESSION['LAST_ACTIVITY'] = time(); 
if(isset($_SESSION['loggedIn']) ){
  checkPrivileges('update');
?>
<div class="panel panel-default">
  <div class="panel-heading">
    <div><h3 class="panel-title">Update File</h3></div>
    <button id='updateBackButton' class='btn btn-default btn-xs'>Back</button>
    <button id='updateResetButton' class='btn btn-default btn-xs'>Reset</button>
    <button id='downloadSample' class='btn btn-default btn-xs'><a href='sample.csv' download='sample.csv'>Download Sample</a></button>
  </div>
  <div class="panel-body">
    <div class="alert alert-info" id='uploadAlertDiv'>
      <!-- <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> -->
      <p></p>
    </div>
    
    <div id='uploadContainer'>
      <div id='progressDiv'>
      <h4>Upload progress</h4>
      <div class="progress progress-striped active" id='progress'>
        <div class="progress-bar"  role="progressbar" aria-valuemin="0" aria-valuemax="100">
          <span class="sr-only">0% Complete</span> <!-- screen readers only -->
        </div>
      </div>
    </div>
    <form id='myForm' enctype='multipart/form-data'>
      <input type="hidden" name='MAX_FILE_SIZE' value = '100000'>  <!-- max size 100KB -->
      <div class="input-group">
        <span class="input-group-btn">
        <span class="btn btn-primary btn-file">
        Browse <input type="file" name='myfile'>  <!-- multiple="" -->
        </span>
        </span>
        <input type="text" class="form-control" readonly="">
      </div>
      <!-- <div class="input-group"> -->
        
      <!-- </div> -->
    </form>
    <button type='submit' class='btn btn-primary' id='submit'>Upload</button>
    <button class='btn btn-primary' id='updateRecords'>Update</button>
    
    <div id="message"></div>
    </div>
  </div>
</div>
<?php
}else{
redirectToLoginPage();
}
?>