<?php

include('base.php');
//include('loginCheck.php');

$conn = connect($_POST['username'],$_POST['password'],'ORCL');
//$conn = connect('surya','oracle1','ORCL');

if(is_resource($conn)){
    echo 'success';
    $_SESSION['LAST_ACTIVITY'] = time();
    //var_dump($_SESSION);
}
    
else{
    session_unset();
    $_SESSION = array();

    if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
    }
    session_destroy();

    // $string = $_GET["data"];
    // //echo $string;

    // $statement = oci_parse($conn, 'SELECT * FROM employees '.$string);
    // //$statement = oci_parse($conn, 'SELECT * FROM employees');
    // oci_execute($statement);

    // //echo "<table border='1'>\n";
    // $resultArray = array();
            
    // while ($row = oci_fetch_array($statement, OCI_ASSOC+OCI_RETURN_NULLS)) {
        
    //     array_push($resultArray,$row);
    //     // echo "<tr>\n";
    //     // foreach ($row as $item) {
    //     //     echo "    <td>" . ($item !== null ? htmlentities($item, ENT_QUOTES) : "&nbsp;") . "</td>\n";
    //     // }
    //     // echo "</tr>\n";
    // }
    // //echo "</table>\n";

    // $json = json_encode((object)$resultArray,JSON_PRETTY_PRINT);
    // echo $json;
    // oci_close($conn);
}


?>