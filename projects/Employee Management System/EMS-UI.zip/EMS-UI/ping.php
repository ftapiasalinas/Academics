<?php
include('base.php');

checkActivity($_GET);
	
	if(isset($_GET['location']))	{
		$link;
		$location = $_GET['location'];
		if($location === 'Los Angeles'){
			$link = '169.254.1.2/orcl';
			//$link = 'localhost/orcl';
		}else 
			if($location === 'Goa'){
				$link = '169.254.1.4/orcl';
			}else
				if($location === 'Delhi'){
					$link = '169.254.1.1/orcl';
				}else
					if($location === 'Mumbai'){
						$link = '169.254.1.3/orcl';
					}

		$conn = @oci_connect('random', 'password', $link, 'AL32UTF8');
		if (!$conn) {
			$e = oci_error();
			//var_dump($e);
			$code = $e['code'];

			if($e['code'] == 1017)
				echo 'Server is up and running.';
			else if($code == 12154)
				echo 'Cannot find server entry. Please contact adminstrator.';
			else if($code == 12170)
				echo 'Cannot connect to server due to timeout. This can be a network/non-responsive server issue.';
			else if($code == 12532)
				echo 'Are you even connected to the network?';
		}else{
		    echo 'Server is up and running';
		}	
	}
	else{
		echo 'Incorrect Request Parameters';
	}


	
	// 1017: invalid uid password... server is up
	// 12154: cannot resolve identifier. invalid TNSNAME configuration. Contact administrator. 
	// 12170: TNS Connect timeout error. either network issue or cannot find server. 
?>