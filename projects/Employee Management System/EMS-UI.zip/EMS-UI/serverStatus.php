<?php
include('base.php');
//&& isset($_SESSION('username') && isset($_SESSION['password'])

// if(isset($_SESSION['LAST_ACTIVITY'])){
//   echo $_SESSION['LAST_ACTIVITY'];
// }else{
//   echo "Not set";
// }

checkActivity($_GET);

$_SESSION['LAST_ACTIVITY'] = time(); 

if(isset($_SESSION['loggedIn'])){
?>
  <div class="header">
    <h2>Server Status</h2>
  </div>
  <div class="alert alert-info alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    Click on a button to check the corresponding server status
  </div>
  <div class='statusButtons'>
    <div>
      <div><button class='btn btn-info btn-lg' >Los Angeles</button></div>
      <div class='alert alert-info alert-dismissable'>
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      </div>
    </div>
    <div>
      <div ><button class='btn btn-info btn-lg' >Mumbai</button></div>
      <div class='alert alert-info alert-dismissable'>
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      </div>
    </div>
    <div>
      <div ><button class='btn btn-info btn-lg' >Delhi</button></div>
      <div class='alert alert-info alert-dismissable'>
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      </div>
    </div>
    <div>
      <div ><button class='btn btn-info btn-lg' >Goa</button></div>
      <div class='alert alert-info alert-dismissable'>
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      </div>
    </div>
  </div>

<?php
}else{
  redirectToLoginPage();
}
?>