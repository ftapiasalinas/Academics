<?php
include('base.php');
//&& isset($_SESSION('username') && isset($_SESSION['password'])

// if(isset($_SESSION['LAST_ACTIVITY'])){
//   echo $_SESSION['LAST_ACTIVITY'];
// }else{
//   echo "Not set";
// }


checkActivity($_GET);

$_SESSION['LAST_ACTIVITY'] = time(); 
if(isset($_SESSION['loggedIn']) ){
?>
  <div class="header">
    <h2>Employee Search</h2>
  </div>
  <div class="innerContent">
    <div class="panel panel-default">
    <div class="panel-heading">
      <div><h3 class="panel-title">Search Employee(s)</h3></div>
    </div>
    <div class="panel-body">
    <div class="alert alert-info alert-dismissable">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    Fill in atleast one field. Blank fields will be not be queried and all matching results shall be displayed.<br/> To search for a single employee ID, enter the same value in both from and to employee ID fields.</div>
    <div class="alert alert-danger alert-dismissable" id="searchError">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    Please check the invalid entries and try again.</div>
    <form class="form-horizontal" role="form">
      <div class="form-group row" >
        <label class="col-lg-2 control-label">Name</label>
        <div class='col-lg-10 row'>
          <div class='col-lg-4'><input type="text" class="form-control" id="name"></div>
          <div class='col-lg-6'><span class='helpText'></span></div>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-lg-2 control-label">Employee ID From</label>
        <div class="col-lg-10 row">
          <div class='col-lg-4'><input type="text" class="form-control" id="empID"></div>
          <div class='col-lg-6'><span class='helpText'></span></div>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-lg-2 control-label">Employee ID To</label>
        <div class="col-lg-10 row">
          <div class ='col-lg-4'><input type="text" class="form-control" id="empID2"></div>
          <div class='col-lg-6'><span class='helpText'></span></div>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-lg-2 control-label">Salary</label>
        <div class="col-lg-10 row">
          <div class ='col-lg-4'><input type="text" class="form-control" id="salary"></div>
          <div class='col-lg-6'><span class='helpText'></span></div>
        </div>
      </div>
      <div class="form-group row">
        <label  class="col-lg-2 control-label">Location</label>
        <div class="col-lg-10 row">
          <div class='col-lg-4'><select class="form-control" id="location">
            <option>All Locations</option>
            <option>Mumbai</option>
            <option>Los Angeles</option>
            <option>Delhi</option>
            <option>Goa</option>
          </select></div>
          <div class='col-lg-6'><span class='helpText'></span></div>
        </div>
      </div>
      <div class="form-group row">
        <label  class="col-lg-2 control-label">PayBand</label>
        <div class="col-lg-10 row">
          <div class='col-lg-4'> <select class="form-control" id="payBand">
            <option>Not Specified</option>
            <option>8000-15000</option>
            <option>15000-25000</option>
            <option>25000-40000</option>
            <option>40000-100000</option>
          </select></div>
          <div class='col-lg-6'><span class='helpText'></span></div>
        </div>
      </div>
      <!-- <div class="form-group row">
        <label  class="col-lg-2 control-label">Joining Date</label>
        <div class="col-lg-10 row">
          <div class ='col-lg-4'><input type="text" class="form-control" id="joiningDate" readonly='true'></div>
          <div class ='col-lg-4'><input type="text" class="form-control" id="joiningDate"></div>
          <div class ='col-lg-1'><button class='btn btn-xs btn-primary resetDate'>Reset</button></div>
          <div class='col-lg-5'><span class='helpText'></span></div>
        </div>
      </div> -->
      <!-- <div class="form-group row">
        <label  class="col-lg-2 control-label">Leaving Date</label>
        <div class="col-lg-10 row">
          
          <div class ='col-lg-4'><input type="text" class="form-control" id="leavingDate"></div>
          <div class ='col-lg-1'><button class='btn btn-xs btn-primary resetDate'>Reset</button></div>
          <div class='col-lg-5'><span class='helpText'></span></div>
        </div>
      </div> -->
      
      <div class="form-group row">
        <label class="col-lg-2 control-label">Skills</label>
        <div class="col-lg-10 skills row">
          <div class ='col-lg-4'><input type="text" class="form-control skills" id="skills"></div>
          <!-- <div class="alert alert-info">To mention multiple skills, enter semi-colon separated values. Ex: PHP;Javascript</div> -->
          <div class='col-lg-6'><span class='helpText'></span></div>
        </div>
      </div>
    </form>
    <label class="col-lg-2 control-label"></label>
    <div class='formControls'>
      <button id="searchSubmit" class="btn btn-info formSubmit" data-href="#resultsHeader" data-for='search'>Search</button>
      <button id="resetForm" class="btn btn-default">Reset</button>
    </div>
    
  </div>
  </div>
</div>
  <div class="resultsHeader" id="resultsHeader">
    <h2>Search Results</h2>
  </div>
  <div id="delay" class="alert alert-info">
    <p>
    <img src="spinner.gif">
    </p>
  </div>
  <div id="responseText">
    <div class="error"></div>
    <table class="table table-bordered table-hover">
    </table>
  </div>





<!-- Modal -->
<div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Confirmation</h4>
      </div>
      <div class="modal-body">
        <p>You have queried to display all employee records. Confirm below to proceed further.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id='confirmQuery'>Confirm</button>
      </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
      
<?php
}else{
  redirectToLoginPage();
  
}
?>