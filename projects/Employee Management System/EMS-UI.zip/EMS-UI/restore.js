function restoreHandlers() {


	$(document).on('click', '#restoreButton', function(event) {
		event.preventDefault();
		/* Act on the event */
		$('#restoreModal').modal('show');
		$('#restore div.modal-body p').text('Are you sure you want to restore the entire local database? This action cannot be undone');

		$('#confirmRestore').click(function(event) {
			/* Act on the event */
			console.log('confirmed restore');
			$('#restoreModal').modal('hide');
			restoreFinal();
		});
	});

	$(document).on('click','#restore button.reset',function(){
		$('#restore div.alert').html('Click on the button below to restore corrupted database <br/> This action will restore the entire local database from the backup servers in Los Angeles <br/> ').addClass('alert-info').removeClass('alert-danger').removeClass('alert-warning');
		$('#restoreButton').show();
	})

}

function restoreFinal() {
	$.ajax({
		url: 'restoreFinal.php?ajax=true&confirm=yes',
		type: 'GET',
		dataType: 'json',
		beforeSend: function(){
			$('#restore div.alert').text('');
			$('#restore div.alert').addClass('alert-info').fadeIn('fast', function() {}).text('Working...');
		}
	})
		.done(function(data) {
			if (jQuery.isPlainObject(data)) {
				console.log(data['status']);
				if (data['status'] == 1) {
					$('#restore div.alert').text('');
					$('#restore div.alert').addClass('alert-warning').removeClass('alert-info').fadeIn('fast', function() {}).text('Local Database has been restored successfully');
				} else if(data['status'] == 0) {
					$('#restore div.alert').text('');
					$('#restore div.alert').addClass('alert-warning').removeClass('alert-info').fadeIn('fast', function() {}).text('Local Database could not be updated');
				} else if(data['status'] == 2){
					$('#restore div.alert').text('');
					$('#restore div.alert').addClass('alert-warning').removeClass('alert-info').fadeIn('fast', function() {}).text('Invalid Input');
				}

				$('#restoreButton').hide();
			} else {
				if (data.indexOf("{'redirect':'true'}") >= 0) {
					window.location.href = 'http://localhost/EMS-UI/login.php?expire=true';
					return;
				}
			}

		})
		.fail(function() {
			$('#restore div.alert').removeClass('alert-info').addClass('alert-warning').fadeIn('fast', function() {}).text('Cannot connect to the server. Contact administrator');
		});
}