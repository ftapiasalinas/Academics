<?php
 session_save_path('C:\\wamp\\www\\EMS-UI\\serverTempFiles\\');
 session_set_cookie_params(0);
 
 session_start();

function checkPrivileges($privilege){

	if($privilege === 'update'){
		if(!(isset($_SESSION['priv']) && $_SESSION['priv'] == 2)){
		    echo "<div class='alert alert-warning' style='width: 50%; margin:auto; margin-top: 1em; margin-bottom: 1em;'>You do not have the privileges to perform database updates</div>";
		    exit(0);
	    }	
	}

	if($privilege === 'delete'){
		if(!(isset($_SESSION['priv']) && $_SESSION['priv'] == 2)){
		    echo "<div class='alert alert-warning' style='width: 50%; margin:auto; margin-top: 1em; margin-bottom: 1em;'>You do not have the privileges to perform database deletes</div>";
		    exit(0);
	    }	
	}

	if($privilege === 'restore'){
		if(!(isset($_SESSION['priv']) && $_SESSION['priv'] == 2)){
		    echo "<div class='alert alert-warning' style='width: 50%; margin:auto; margin-top: 1em; margin-bottom: 1em;'>You do not have the privileges to perform database restore</div>";
		    exit(0);
	    }	
	}
} 

function classifyRequestType($array){

		
}

function redirectToLoginPage($timeout,$array){

	$decision;

	if(isset($array['ajax']) && $array['ajax'] === 'true'){
		$decision = true;
	}		
	else{
		$decision = false;
	}

	if($timeout){
		if($decision)
			echo "{'redirect':'true'}";
		else
			header('Location:login.php?expire=true');	
	}else{
		header('Location:login.php');	
	}
	
	//@session_start();
	session_unset();     
	session_destroy();   
	$_SESSION = array();
	//echo "redirect";
	//http_redirect('http://localhost/EMS-UI/login.html');
	//header('Location:login.html');
	exit(0);
}

function checkActivity($array){

	//var_dump($_SESSION);
	//var_dump($array);

	if (isset($_SESSION['LAST_ACTIVITY'])){
		if((time() - $_SESSION['LAST_ACTIVITY'] > 900)){
			redirectToLoginPage(true,$array);	
		}
	}else{
		redirectToLoginPage(false,$array);
	} 		
}

function connect($username,$password,$tnsname){
	$conn = @oci_connect($username, $password, $tnsname, 'AL32UTF8');
	if (!$conn) {
		$e = oci_error();
		echo $e['message'];
		return false;
	}else{
	    $_SESSION['loggedIn'] = true;
	    $_SESSION['username'] = $username;
	    $_SESSION['password'] = $password;

	    // set the global session prefix
	    //$sql = 'select priv from PERMISSIONS where username = \''.$_SESSION['username'].'\'';
	    $sql = 'select username from PERMISSIONS where priv = 2';

		$stmt = oci_parse($conn,$sql);
		oci_execute($stmt);

		while ($row = oci_fetch_array($stmt, OCI_ASSOC+OCI_RETURN_NULLS)) {
			//var_dump($row);
		    $_SESSION['prefix'] = $row['USERNAME'];
		}

		// set the permissions level

		$sql = 'select priv from PERMISSIONS where username = \''.$_SESSION['username'].'\'';

		$stmt = oci_parse($conn,$sql);
		oci_execute($stmt);
				
		while ($row = oci_fetch_array($stmt, OCI_ASSOC+OCI_RETURN_NULLS)) {
		    $_SESSION['priv'] = $row['PRIV'];
		}

		return $conn;
	}
}
?>