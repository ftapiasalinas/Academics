function pipeUpdates(list) {
	var list = [];

	$('tbody tr').each(function() {
		if ($(this).data('valid'))
			list.push($(this).data('modifiedValues'));
	})
	//console.log(list);
	postUpdate(JSON.stringify(list));
	//console.log(JSON.stringify(list));
}

function printManualUpdateResult(data) {

	var text = '';
	for (item in data) {
		if (!data[item]) {
			text += '<p>Employee with ID number ' + item + ' could not be updated.</p>';
		}
	}
	if (text === '')
		text = '<p>All Employee IDs have been updated successfully.</p>';
	else
		text += '<p>All other Employee IDs have been updated. For unsuccessful updates, please check provided input for errors and retry</p>';


	$('#updateInfo')
		.fadeIn('fast', function() {}).removeClass('alert-danger').addClass('alert-success').html(text);

	var $target = $('#updateInfo');
		
	$('html, body').stop().animate({
		'scrollTop': $target.offset().top
	}, 300, 'swing', function() {
		window.location.hash = 'updateInfo';
	});

	setTimeout(function(){
		$('#updateInfo').fadeOut('fast', function() {
			
		});
	},3000);

}

function postUpdate(json) {
	// var ajaxRequest = getAjaxObject(); // calling func before it is defined... may cause issues
	// ajaxRequest.onreadystatechange = function(){
	// 	if(ajaxRequest.readyState == 4){
	// 		console.log('Successfully posted');
	// 		console.log(ajaxRequest.responseText);
	// 	}
	// }	
	// ajaxRequest.open('POST','processManualUpdate.php');
	// ajaxRequest.send(json);


	$.ajax({
		url: 'processManualUpdate.php?ajax=true',
		type: 'POST',
		dataType: 'html',
		data: {
			'json': json
		},
	})
		.done(function(data) {
			//if (jQuery.isPlainObject(data)) {
				if (data.indexOf("{'redirect':'true'}") >= 0) {
					window.location.href = 'http://localhost/EMS-UI/login.php?expire=true';
					return;
				}
				console.log('plain object');
				printManualUpdateResult(data);
				$('#responseText table').fadeOut('fast', function() {});
				$('#submitUpdates').fadeOut('fast', function() {});
			//} else {
				
			//}
		})
		.fail(function(jqXHR, textStatus) {
			console.log(textStatus);
			$('#updateInfo').addClass('alert-danger').removeClass('alert-info').removeClass('alert-danger').text('Cannot connect to server. Please contact administrator');
		});
}


function manualUpdateHandlers() {
	$('#updateBackButton2').click(function(event) {
		/* Act on the event */
		$('#manualUpdateDiv')
			.html('')
			.fadeOut('fast', function() {
				$('#choicesPanel').fadeIn('fast', function() {
					updateHandlers();
				});
			});
	});



	$(document).on('click', '#submitUpdates', function(event) {
		event.preventDefault();
		var list = [];
		$('tbody tr').each(function() {
			if ($(this).data('valid'))
				list.push($(this));
		});

		if (list.length == 0) {
			$('#responseText div.error').addClass('alert-danger').addClass('alert').text('Please validate at least one record');
			var $target = $('#responseText');
		
			$('html, body').stop().animate({
				'scrollTop': $target.offset().top
			}, 300, 'swing', function() {
				window.location.hash = 'responseText';
			});

		} else {
			$('#responseText div.error').removeClass('alert-danger').addClass('alert-info').fadeOut('slow/400/fast', function() {});
			pipeUpdates();
		}

		//console.log(list);
		/* Act on the event */
	});

	//	var tableRows =	$('input.global-check').parents('thead').siblings('tbody').children('tr');

	// tableRows.on(function(index, el) {
	// 	$this = $(this);

	// });

	// $('input.item-check').on('click',function(event) {
	// 	/* Act on the event */
	// 	//$(this).click();

	// });

	// $('input.global-check').on('click',function(event){
	// 	$('input.item-check').each(function(){
	// 		$this = $(this);
	// 		if(!$this.is(':checked'))
	// 			$this.click();
	// 	});	
	// });
	function validateFields(handle) {


		var tds = handle.parents('tr').children('td');

		var id = tds.eq(0).text();
		var name = tds.eq(1).text();
		var joindate = tds.eq(3).text();
		var payscale = tds.eq(2).children().eq(0).val();
		var enddate = tds.eq(4).children().eq(0).val();
		var skills = tds.eq(5).children().eq(0).val();
		var salary = parseInt(tds.eq(6).children().eq(0).val());

		if (payscale === tds.eq(2).data('old') && enddate === tds.eq(4).data('old') && skills === tds.eq(5).data('old') && salary === parseInt(tds.eq(6).data('old'))) {
			console.log('test');
			handle.text('No Change').removeClass('btn-warning').addClass('btn-info');
			setTimeout(function() {
				handle.text('Validate').removeClass('btn-danger').addClass('btn-info');
			}, 3000);
			return;
		}

		var range = payscale.split('-');

		console.log(payscale + " " + enddate + " " + skills + " " + salary + " " + range[0] + " " + range[1]);

		console.log(helpTexts['leavingDate'].regex.test(enddate));
		console.log(helpTexts['skills'].regex.test(skills));
		console.log(helpTexts['salary'].regex.test(salary));
		console.log((salary >= parseInt(range[0]) && salary <= parseInt(range[1])));

		if (!helpTexts['leavingDate'].regex.test(enddate) || !helpTexts['skills'].regex.test(skills) || !helpTexts['salary'].regex.test(salary)) {
			handle.text('Invalid').removeClass('btn-info').addClass('btn-danger');
			setTimeout(function() {
				handle.text('Validate').removeClass('btn-danger').addClass('btn-info');
			}, 3000);
		} else {
			if (!(salary >= parseInt(range[0]) && salary <= parseInt(range[1]))) {
				handle.text('Invalid').removeClass('btn-info').addClass('btn-danger');
				setTimeout(function() {
					handle.text('Validate').removeClass('btn-danger').addClass('btn-info');
				}, 3000);
			} else {
				handle.text('Validated')
					.removeClass('btn-info')
					.addClass('btn-success');
				handle.parents('tr').data('valid', true);
				var data = {};
				data['ID'] = id;
				data['NAME'] = name;
				data['PAYSCALE'] = payscale;
				data['JOINDATE'] = joindate;
				data['ENDDATE'] = enddate;
				data['SKILLS'] = skills;
				data['SALARY'] = salary;
				console.log(data);
				handle.parents('tr').data('modifiedValues', data);
			}
		}
	}

	$("input.inlineLeavingDate").datepicker({
		changeMonth: true,
		changeYear: true,
		showAnim: "fadeIn",
		minDate: '01/01/2000',
		maxDate: 0,
		yearRange: '2000:+00'
	});

	$(document).on('click', 'button.item-update-button', function(event) {
		event.preventDefault();
		/* Act on the event */

		var $this = $(this);
		var tds = $this.parents('tr').children('td');



		// 2 4 5 6
		var payscale = tds.eq(2).data('old');
		var enddate = tds.eq(4).data('old');
		var skills = tds.eq(5).data('old');
		var salary = tds.eq(6).data('old');
		var text;

		// tds.eq(2).data('old', payscale);
		// tds.eq(4).data('old', enddate);
		// tds.eq(5).data('old', skills);
		// tds.eq(6).data('old', salary);


		var $this = $(this);

		if ($this.text() === 'Edit')
			text = true;
		else
			text = false;

		if (text) {
			console.log("Editing");

			tds.eq(2).html('<select class="form-control"><option>8000-15000</option><option>15000-25000</option><option>25000-40000</option><option>40000-100000</option></select>'); //.attr('selected',payscale);
			tds.eq(4).html('<input type="text" class="inlineLeavingDate form-control" readonly="true">');
			tds.eq(5).html('<input type="text" class="form-control">');
			tds.eq(6).html('<input type="text" class="form-control">');

			tds.eq(2).children().eq(0).val(payscale);
			tds.eq(4).children().eq(0).attr('placeholder', enddate).val(enddate);
			tds.eq(5).children().eq(0).attr('placeholder', skills).val(skills);
			tds.eq(6).children().eq(0).attr('placeholder', salary).val(salary);

			$("input.inlineLeavingDate").datepicker({
				changeMonth: true,
				changeYear: true,
				showAnim: "fadeIn",
				minDate: '01/01/2000',
				maxDate: 0,
				yearRange: '2000:+00'
			});

			$this.text('Validate');
		} else {
			validateFields($(this));
		}
	});

	// $('button.item-update-button').live('click', function(event) {
	// 	console.log("Working?");
	// 	$this = $(this);
	// 	var text;
	// 	if($this.text() === 'Edit')
	// 		text = true;
	// 	else
	// 		text = false;

	// 	if(text){
	// 		console.log("Editing");
	// 		tds = $this.parents('tr').children('td');
	// 		// 2 4 5 6
	// 		var payscale = tds.eq(2).val();
	// 		var enddate = tds.eq(4).val();
	// 		var skills = tds.eq(5).val();
	// 		var salary = tds.eq(6).val();

	// 		tds.eq(2).html('<select class="form-control"><option>8000-15000</option><option>15000-25000</option><option>25000-40000</option><option>40000-100000</option></select>').text(payscale);
	// 		tds.eq(4).html('<input type="text" class="inlineLavingDate form-control" readonly="true">').text(enddate);
	// 		tds.eq(5).html('<input type="text"> class="form-control"').text(skills);
	// 		tds.eq(6).html('<input type="text"> class="form-control"').text(salary);

	// 		$this.text('Validate');
	// 	}else{
	// 		validateFields($this);
	// 	}
	// 	/* Act on the event */
	// });

	$(document).on('click', 'button.global-update-button', function(event) {
		event.preventDefault();
		$('button.item-update-button').click();
		/* Act on the event */
	});

	$(document).on('click', 'button.global-reset-button', function(event) {
		event.preventDefault();
		$('button.item-reset-button').click();
		/* Act on the event */
	});

	$(document).on('click', 'button.item-reset-button', function(event) {
		event.preventDefault();
		var $this = $(this);
		var tds = $this.parents('tr').children('td');
		tds.eq(7).children().eq(0).removeClass('btn-danger').removeClass('btn-success').addClass('btn-info').text('Edit');
		tds.eq(2).html(tds.eq(2).data('old'));
		tds.eq(4).html(tds.eq(4).data('old'));
		tds.eq(5).html(tds.eq(5).data('old'));
		tds.eq(6).html(tds.eq(6).data('old'));
	});


}