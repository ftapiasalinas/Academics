<?php
include('base.php');
//&& isset($_SESSION('username') && isset($_SESSION['password'])
checkActivity($_GET);

$_SESSION['LAST_ACTIVITY'] = time(); 
if(isset($_SESSION['loggedIn']) ){
    
    checkPrivileges('delete');

?>
<div class="header">
	<h2>Delete</h2>
</div>
<div class="panel panel-default">
	<div class="panel-heading">
		<div><h3 class="panel-title">Delete Employee Records</h3></div>
		<button class='btn btn-default btn-xs reset'>Reset</button>
	</div>
	<div class="panel-body">
		<div class='alert alert-info'>This is a info div</div>
		<div class='controlWrapper'>
			<label class="control-label">Employee ID</label>
			<input type="text" class='form-control' id='deleteID'>
			<button class='btn btn-info' id='fetchEmployee'>Fetch Employee</button>
			<button class='btn btn-warning' id='deleteButton'>Delete Employee</button>
		</div>
		<table class="table table-bordered table-hover">
			<thead>
				<tr>
					<td>ID</td>
					<td>NAME</td>
					<td>PAYSCALE</td>
					<td>JOINDATE</td>
					<td>ENDDATE</td>
					<td>SKILLS</td>
					<td>SALARY</td>
				</tr>
			</thead>
			<tbody>
				<tr>
					
				</tr>
			</tbody>
    	</table>

	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="deleteModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" >Confirmation</h4>
      </div>
      <div class="modal-body">
        <p></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" id='confirmDelete'>Confirm</button>
      </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
  
<?php
}else{
  redirectToLoginPage();
}
?>