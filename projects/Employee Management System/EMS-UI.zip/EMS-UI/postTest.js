var list = [{
	"ID": "160",
	"NAME": "hekrlhb",
	"PAYSCALE": "8000-15000",
	"JOINDATE": "02/15/1991",
	"ENDDATE": "04/28/2031",
	"SKILLS": "c, python, java",
	"SALARY": 10004
}, {
	"ID": "161",
	"NAME": "qfmlfak",
	"PAYSCALE": "15000-25000",
	"JOINDATE": "05/25/2028",
	"ENDDATE": "07/18/1990",
	"SKILLS": "test matlab, c#",
	"SALARY": 16000
}];


function postUpdate(json){
	// var ajaxRequest = getAjaxObject(); // calling func before it is defined... may cause issues
	// ajaxRequest.onreadystatechange = function(){
	// 	if(ajaxRequest.readyState == 4){
	// 		console.log('Successfully posted');
	// 		console.log(ajaxRequest.responseText);
	// 	}
	// }	
	// ajaxRequest.open('POST','processManualUpdate.php');
	// ajaxRequest.send(json);

	$.ajax({
		url: 'processManualUpdate.php',
		type: 'POST',
		dataType: 'html',
		data: {'json': json},
	})
	.done(function(data) {
		console.log(data);
	})
	.fail(function(jqXHR,textStatus) {
		console.log(textStatus);
	});
}


