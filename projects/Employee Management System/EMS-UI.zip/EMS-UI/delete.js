function validateID() {
	var regex = /\b([1-9][0-9]?|[1-4][0-9]{2}|500)\b/;
	if (regex.test($('#deleteID').val())) {
		setTimeout(function() {
			fetchRecord($('#deleteID').val());
		}, 500);

		$('#delete div.alert')
			.text('Please wait while record is being fetched')
			.addClass('alert-info')
			.removeClass('alert-warning')
			.fadeIn('fast', function() {});

		var img = document.createElement('img');
		img.setAttribute('src', 'spinner.gif');

		$('#delete div.alert').append(img);

	} else {
		$('#delete div.alert').removeClass('alert-info').addClass('alert-warning').fadeIn('fast', function() {}).text('Enter an valid ID in the range 1 - 500');
	}
}

function displayEmployee(data) {
	console.log(data);


	var count = 0;
	for (record in data) {
		count++;
		$('#delete tbody tr').html('');
		for (attr in data[record]) {
			$('#delete tbody tr').append('<td>' + data[record][attr] + '</td>')
		}

	}

	if (count != 1) {
		$('#delete div.alert').removeClass('alert-info').addClass('alert-warning').fadeIn('fast', function() {}).text('Unexpected Input Receieved');
		return;
	}
	$('#deleteID').prop('readonly', true);
	$('#delete table').fadeIn('fast', function() {});
	$('#deleteButton').fadeIn('fast', function() {});
	$('#deleteID').data('id', parseInt($('tbody tr td').eq(0).text()));
}


function fetchRecord(id) {
	$.ajax({
		url: 'fetchEmployee.php?ajax=true',
		type: 'GET',
		dataType: 'json',
		data: {
			'id': id
		},
	})
		.done(function(data) {
			if (jQuery.isPlainObject(data)) {
				console.log("ssdlkjflksdf");
				$('#delete div.alert').fadeOut('fast', function() {});
				$('#fetchEmployee').hide();
				displayEmployee(data);
			} else {
				if (data.indexOf("{'redirect':'true'}") >= 0) {
					window.location.href = 'http://localhost/EMS-UI/login.php?expire=true';
					return;
				}
			}
		})
		.fail(function() {
			$('#delete div.alert').removeClass('alert-info').addClass('alert-warning').fadeIn('fast', function() {}).text('Cannot connect to the server. Contact administrator');
		});
}

function deleteHandlers() {
	$(document).on('click', '#fetchEmployee', function(event) {
		event.preventDefault();
		validateID();
		/* Act on the event */
	});

	$(document).on('click', '#deleteButton', function(event) {
		event.preventDefault();
		/* Act on the event */
		$('#deleteModal').modal('show');
		$('#delete div.modal-body p').text('Are you sure you want to delete Employee ID ' + $('#deleteID').data('id') + ' ? This cannot be undone');

		$('#confirmDelete').click(function(event) {
			/* Act on the event */
			console.log('confirmed delete');
			$('#deleteModal').modal('hide');
			deleteFinal();
		});
	});

	$(document).on('click', '#delete button.reset', function(event) {
		$('#delete div.alert').fadeOut('fast', function() {}).text('').removeClass('alert-warning').addClass('alert-info');
		$('#deleteButton').hide();
		$('#fetchEmployee').show();
		$('#delete table').hide().children('tbody tr').html('');
		$('#deleteID').data('id','').prop('readonly',false).val('');
	});
}

function deleteFinal() {
	$.ajax({
		url: 'deleteFinal.php?ajax=true',
		type: 'POST',
		dataType: 'json',
		data: {
			'id': $('#deleteID').data('id')
		},
	})
		.done(function(data) {
				if (jQuery.isPlainObject(data)) {
					console.log(data['id'] + " " + data['status']);
					if (data['status'] == 1) {
						$('#delete div.alert').text('');
						$('#delete div.alert').addClass('alert-warning').removeClass('alert-info').fadeIn('fast', function() {}).text('Employee Record with ID = ' + data['id'] + ' has been deleted');
					} else {
						$('#delete div.alert').text('');
						$('#delete div.alert').addClass('alert-warning').removeClass('alert-info').fadeIn('fast', function() {}).text('Employee Record with ID = ' + data['id'] + ' was not deleted');
					}
				} else {
					if (data.indexOf("{'redirect':'true'}") >= 0) {
						window.location.href = 'http://localhost/EMS-UI/login.php?expire=true';
						return;
					}
				}

		})
		.fail(function() {
			$('#delete div.alert').removeClass('alert-info').addClass('alert-warning').fadeIn('fast', function() {}).text('Cannot connect to the server. Contact administrator');
		});
}