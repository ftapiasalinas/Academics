function updateHandlers() {
	$('#updateChoiceButton').click(function(event) {
		/* Act on the event */
		console.log('Event fired');
		var option;
		var response;
		var ajaxRequest;
		if ($('#uploadFile').prop('checked')) {
			$('div#update div.panel').fadeOut('fast', function() {
				console.log('Fading panel out');
				ajaxRequest = getAjaxObject();
				ajaxRequest.onreadystatechange = function() {
					if (ajaxRequest.readyState == 4) {
						if (ajaxRequest.responseText.indexOf("{'redirect':'true'}") >= 0) {
							window.location.href = 'http://localhost/EMS-UI/login.php?expire=true';
							return;
						}
						response = ajaxRequest.responseText;
						$('#uploadFileDiv').html(response);
						$('#uploadFileDiv').fadeIn('fast', function() {
							console.log('Fading in upload File div');
						});
						fileUploadHandlers();
					} 
				}
				ajaxRequest.open('GET', 'fileUpload.php?ajax=true', true);
				ajaxRequest.send(null);
			});
		} else {
			$('div#update div.panel').fadeOut('fast', function() {
				console.log('Fading panel out');
				$('#manualUpdateDiv').fadeIn('fast', function() {
					console.log('Fading in manual upload div');
					ajaxRequest = getAjaxObject();
					ajaxRequest.onreadystatechange = function() {
						if (ajaxRequest.readyState == 4) {
							if (ajaxRequest.responseText.indexOf("{'redirect':'true'}") >= 0) {
								window.location.href = 'http://localhost/EMS-UI/login.php?expire=true';
								return;
							}
							response = ajaxRequest.responseText;
							$('#manualUpdateDiv')
								.html(response)
								.fadeIn('fast', function() {
									console.log('Fading in manual upload Div');
									$('#search').html('');
									searchHandlers();
								});
							manualUpdateHandlers();
						}
					}
					ajaxRequest.open('GET', 'manualUpdate.php?ajax=true', true);
					ajaxRequest.send(null);
				});
			});
		}
	});
}