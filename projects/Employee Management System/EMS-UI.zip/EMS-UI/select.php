<?php
include('base.php');

checkActivity($_GET);

$conn = connect($_SESSION['username'],$_SESSION['password'],'ORCL');

$string = $_GET["data"];
$minval = intval($_GET["minval"]);
$maxval = intval($_GET["maxval"]);

//echo $string;
//echo $minval;
//echo $maxval;
$attr = 'id';


if(isset($_GET['location'])){
	//echo 'printing';
	//echo $string;

	$location = $_GET['location'];
	//echo $location;
	if(isset($_SESSION['prefix']))
		$sql = 'BEGIN '.$_SESSION['prefix'].'.select_local_employees(:whereclause, :site); END;';
	else
		$sql = 'BEGIN select_local_employees(:whereclause, :site); END;';
	$stmt = oci_parse($conn,$sql);

	oci_bind_by_name($stmt,':whereclause',$string,200,SQLT_CHR);

	//  Bind the input parameter
	oci_bind_by_name($stmt,':site',$location,200,SQLT_CHR);
	oci_execute($stmt);
}
	

else{

	if(isset($_SESSION['prefix']))
		$sql = 'BEGIN '.$_SESSION['prefix'].'.select_employee(:whereclause, :attr, :minval, :maxval); END;';
	else
		$sql = 'BEGIN select_employee(:whereclause, :attr, :minval, :maxval); END;';

	$stmt = oci_parse($conn,$sql);

	//  Bind the input parameter
	oci_bind_by_name($stmt,':whereclause',$string,200,SQLT_CHR);

	//  Bind the input parameter
	oci_bind_by_name($stmt,':attr',$attr,200,SQLT_CHR);

	//  Bind the input parameter
	oci_bind_by_name($stmt,':minval',$minval,200,SQLT_INT);

	//  Bind the input parameter
	oci_bind_by_name($stmt,':maxval',$maxval,200,SQLT_INT);

	oci_execute($stmt);
}
if(isset($_SESSION['prefix']))
	$stid = oci_parse($conn, 'SELECT * FROM '.$_SESSION['prefix'].'.output_employee order by id');
else
	$stid = oci_parse($conn, 'SELECT * FROM output_employee order by id');
oci_execute($stid);

$resultArray = array();

while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
    array_push($resultArray,$row);
}

$json = json_encode((object)$resultArray);
echo $json;

?>

