cd /run/media/sahil/Sahil\'s\ Gallery/Documents/Dropbox/Academics/sem\ 3-2/CP\ PA\ docs/Lab2/Memory
grep - HD/file1.txt | sort
