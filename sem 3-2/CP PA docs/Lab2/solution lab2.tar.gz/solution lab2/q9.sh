# to append string to file we can use echo 
# and for some processed output we can use >> operator
cd /run/media/sahil/Sahil\'s\ Gallery/Documents/Dropbox/Academics/sem\ 3-2/CP\ PA\ docs/Lab2/Memory
echo "Line count of HD/file3.txt" >> MM/file17.txt
cat HD/file3.txt | wc -l >> MM/file17.txt
echo "Line count of Cache/file3.txt" >> MM/file17.txt
cat Cache/file3.txt | wc -l >> MM/file17.txt
