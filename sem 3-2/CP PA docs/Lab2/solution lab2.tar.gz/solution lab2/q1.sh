cd /run/media/sahil/Sahil\'s\ Gallery/Documents/Dropbox/Academics/sem\ 3-2/CP\ PA\ docs/Lab2
mkdir Memory
cd Memory
mkdir HD
mkdir Cache
cd HD
echo "Whatever the mind of man can conceive and believe, it can achieve
-Napoleon Hill
Strive not be a success, but rather to of value
-Albert Einstein
Every strike brings me closer to the next home run
-Babe Ruth" > file1.txt

echo "I am not a product of my circumstances.
I am a product of my decisions.
-Stephen Covey
Every child is an artist. The
problem is how to remain
an artist once he growns up.
-Pablo Picasso
A truly rich man is one
whose children run into his arms
when his hands are empty.
-Unknown" > file2.txt

cd ../Cache
echo "2
9.08
5.3
8
78.3" > file1.txt
echo "8
43.2
897.5
3.2
67.4
876.3"> file2.txt

