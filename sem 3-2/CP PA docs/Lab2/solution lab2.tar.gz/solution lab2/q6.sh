# first change the directory if not there
# we concatenate the contents of file1.txt and file2.txt and then send this output to wordcount
cd /run/media/sahil/Sahil\'s\ Gallery/Documents/Dropbox/Academics/sem\ 3-2/CP\ PA\ docs/Lab2/Memory
cat MM/file?.txt | wc -l
